"""
Симуляция социальных агентов, КИБЕР РЫВОК 2026.

Архитектура:
- Backend: FastAPI + LangGraph (граф состояний reflect, act) + WebSocket для real-time.
- Аутентификация: JWT-подобные сессии (Bearer), пароли PBKDF2-SHA256.
- LLM: Focus API (focusapi.ru), промпты на русском, ответы очищаются до кириллицы.
- Состояние: глобальный global_state (агенты, события), граф отношений NetworkX.
- Опционально: векторная БД (Chroma + HuggingFace embeddings) для долгосрочной памяти.
"""
import asyncio
import os
import random

from dotenv import load_dotenv

# Загружаем переменные из .env; если файла нет, из .env.example (шаблон с ключами)
_env_dir = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(_env_dir, ".env"))
load_dotenv(os.path.join(_env_dir, ".env.example"))
import re
import json
import time
import secrets
import hashlib
from pathlib import Path
from contextlib import asynccontextmanager
from typing import Dict, List, TypedDict, Annotated, Optional, Tuple

from langchain_core.language_models import BaseChatModel
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.messages import AIMessage
from langgraph.graph import StateGraph, START, END
import networkx as nx
import uvicorn

# Lifespan: при старте приложения запускается фоновая симуляция, при остановке отменяется
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    task = asyncio.create_task(simulate())
    yield
    # Shutdown
    task.cancel()


app = FastAPI(lifespan=lifespan)
# CORS нужен, чтобы фронт с другого порта (например статика с :5500) мог ходить на API :8000
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# LLM: используется Focus API (focusapi.ru); без ключа симуляция работает с заглушками
FOCUS_API_KEY = os.getenv("FOCUS_API_KEY", "").strip()

llm_primary: Optional[BaseChatModel] = None
if FOCUS_API_KEY:
    from langchain_openai import ChatOpenAI
    _max_tokens = max(128, min(int(os.getenv("LLM_MAX_TOKENS", "512")), 4096))
    _request_timeout = max(30, min(int(os.getenv("LLM_REQUEST_TIMEOUT", "90")), 300))
    llm_primary = ChatOpenAI(
        model=os.getenv("FOCUS_MODEL", "focus-ai"),
        base_url=os.getenv("FOCUS_BASE_URL", "https://focusapi.ru"),
        api_key=FOCUS_API_KEY,
        temperature=0.7,
        max_tokens=_max_tokens,
        request_timeout=_request_timeout,
    )
    print("LLM: Focus API (focusapi.ru), timeout", _request_timeout, "s")
else:
    print("FOCUS_API_KEY не задан — LLM отключён.")


_logged_402 = False
_logged_429 = False
_logged_connection = False
_retry_delay_429 = max(3, int(os.getenv("LLM_RETRY_DELAY_429", "15")))
_retry_delay_connection = max(2, int(os.getenv("LLM_RETRY_DELAY_CONNECTION", "5")))
_max_connection_retries = max(2, min(5, int(os.getenv("LLM_CONNECTION_RETRIES", "3"))))


def _is_connection_error(e: Exception) -> bool:
    """Ошибки соединения/таймаута — имеет смысл повторять запрос."""
    err_str = str(e).lower()
    return (
        "connection" in err_str
        or "connect" in err_str
        or "timeout" in err_str
        or "timed out" in err_str
        or "connection error" in err_str
        or "connection refused" in err_str
        or "network" in err_str
        or "econnrefused" in err_str
        or "econnreset" in err_str
    )


# Вызов LLM с повтором при 429 (rate limit), при ошибках соединения и однократным логированием 402/429
async def run_llm_text(prompt: ChatPromptTemplate, variables: Dict) -> str:
    global _logged_402, _logged_429, _logged_connection
    if llm_primary is None:
        raise RuntimeError("LLM unavailable: задай FOCUS_API_KEY")
    chain = prompt | llm_primary
    last_error = None
    max_attempts = _max_connection_retries + 2  # достаточно итераций для 429 + connection retries
    for attempt in range(max_attempts):
        try:
            msg = await chain.ainvoke(variables)
            raw = _extract_llm_text(msg) if hasattr(msg, "content") else str(msg).strip()
            result = clean_message_to_russian(raw)
            if not result and raw:
                result = raw.strip()[:500]
            if not result:
                print("LLM вернул пустой ответ (проверь формат ответа модели).")
                return "Продолжаю."
            return result
        except Exception as e:
            last_error = e
            err_str = str(e).lower()
            if "402" in err_str or "insufficient balance" in err_str:
                if not _logged_402:
                    _logged_402 = True
                    print(
                        "--- 402 Insufficient Balance: недостаточно средств на счёте API. "
                        "Пополни баланс или уменьши нагрузку. ---"
                    )
                raise
            if "429" in err_str or "rate-limited" in err_str or "rate limit" in err_str or "resource_exhausted" in err_str:
                if not _logged_429:
                    _logged_429 = True
                    print(f"--- 429 Rate limit. Повтор через {_retry_delay_429} с ---")
                if attempt < 2:
                    await asyncio.sleep(_retry_delay_429)
                    continue
                raise
            if _is_connection_error(e):
                if not _logged_connection:
                    _logged_connection = True
                    print(f"--- Ошибка соединения с LLM. Повтор до {_max_connection_retries} раз с паузой {_retry_delay_connection} с ---")
                if attempt < _max_connection_retries:
                    await asyncio.sleep(_retry_delay_connection)
                    continue
                raise
            raise
    raise last_error


# Опциональная векторная БД (Chroma + multilingual MiniLM), долгосрочная память агентов; ENABLE_VECTOR_DB=1
ENABLE_VECTOR_DB = os.getenv("ENABLE_VECTOR_DB", "0") == "1"
vector_db = None
if ENABLE_VECTOR_DB:
    try:
        from langchain_huggingface import HuggingFaceEmbeddings  # type: ignore
    except Exception:
        from langchain_community.embeddings import HuggingFaceEmbeddings  # type: ignore
    from langchain_chroma import Chroma
    from langchain_core.documents import Document

    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")
    vector_db = Chroma(collection_name="agent_memories", embedding_function=embeddings)


# Аутентификация: пользователи и сессии хранятся в JSON-файлах рядом с app.py
USERS_PATH = Path(__file__).with_name("users.json")
SESSIONS_PATH = Path(__file__).with_name("sessions.json")
_users: Dict[str, Dict] = {}
_sessions: Dict[str, Dict] = {}
SESSION_TTL_SECONDS = 60 * 60 * 24 * 7  # 7 дней


def _load_sessions() -> None:
    global _sessions
    if SESSIONS_PATH.exists():
        try:
            data = json.loads(SESSIONS_PATH.read_text(encoding="utf-8"))
            now = time.time()
            _sessions = {k: v for k, v in (data or {}).items() if isinstance(v, dict) and v.get("exp", 0) > now}
            if len(_sessions) != len(data or {}):
                _save_sessions()
        except Exception:
            _sessions = {}
    else:
        _sessions = {}


def _save_sessions() -> None:
    try:
        SESSIONS_PATH.write_text(json.dumps(_sessions, ensure_ascii=False, indent=0), encoding="utf-8")
    except Exception:
        pass


def _load_users() -> None:
    global _users
    if USERS_PATH.exists():
        try:
            _users = json.loads(USERS_PATH.read_text(encoding="utf-8"))
        except Exception:
            _users = {}
    else:
        _users = {}


def _save_users() -> None:
    USERS_PATH.write_text(json.dumps(_users, ensure_ascii=False, indent=2), encoding="utf-8")


# Пароли не храним в открытом виде: PBKDF2-HMAC-SHA256, 150k итераций (устойчивость к перебору)
def _hash_password(password: str, salt_hex: str) -> str:
    salt = bytes.fromhex(salt_hex)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 150_000)
    return dk.hex()


def _make_salt() -> str:
    return secrets.token_bytes(16).hex()


def _new_session(username: str) -> str:
    global _sessions
    token = secrets.token_urlsafe(32)
    _sessions[token] = {"username": username, "exp": time.time() + SESSION_TTL_SECONDS}
    _save_sessions()
    return token


def _get_username_from_auth(authorization: Optional[str]) -> Optional[str]:
    global _sessions
    if not authorization:
        return None
    # Bearer <token>
    parts = authorization.split(" ", 1)
    if len(parts) != 2 or parts[0].lower() != "bearer":
        return None
    token = parts[1].strip()
    if not _sessions and SESSIONS_PATH.exists():
        _load_sessions()
    sess = _sessions.get(token)
    if not sess:
        return None
    if sess["exp"] < time.time():
        _sessions.pop(token, None)
        _save_sessions()
        return None
    return sess["username"]


_load_sessions()


@app.post("/auth/register")
def auth_register(payload: Dict):
    _load_users()
    username = str(payload.get("username", "")).strip().lower()
    password = str(payload.get("password", ""))
    display_name = str(payload.get("display_name", "")).strip()

    if not re.fullmatch(r"[a-z0-9_\\-]{3,32}", username):
        raise HTTPException(status_code=400, detail="Логин: 3–32 символа, латиница/цифры/_, -.")
    if len(password) < 6:
        raise HTTPException(status_code=400, detail="Пароль должен быть минимум 6 символов.")
    if username in _users:
        raise HTTPException(status_code=409, detail="Такой логин уже занят.")

    salt = _make_salt()
    _users[username] = {
        "username": username,
        "display_name": display_name or username,
        "salt": salt,
        "password_hash": _hash_password(password, salt),
        "created_at": int(time.time()),
    }
    _save_users()
    return {"status": "ok"}


@app.post("/auth/login")
def auth_login(payload: Dict):
    _load_users()
    username = str(payload.get("username", "")).strip().lower()
    password = str(payload.get("password", ""))
    u = _users.get(username)
    if not u:
        raise HTTPException(status_code=401, detail="Неверный логин или пароль.")
    if _hash_password(password, u["salt"]) != u["password_hash"]:
        raise HTTPException(status_code=401, detail="Неверный логин или пароль.")
    token = _new_session(username)
    return {"status": "ok", "token": token, "user": {"username": username, "display_name": u["display_name"]}}


@app.get("/auth/me")
def auth_me(authorization: Optional[str] = Header(default=None, alias="Authorization")):
    _load_users()
    username = _get_username_from_auth(authorization)
    if not username:
        raise HTTPException(status_code=401, detail="Не авторизован.")
    u = _users.get(username) or {}
    return {"username": username, "display_name": u.get("display_name", username)}


@app.post("/auth/logout")
def auth_logout(authorization: Optional[str] = Header(default=None, alias="Authorization")):
    parts = (authorization or "").split(" ", 1)
    if len(parts) == 2 and parts[0].lower() == "bearer":
        _sessions.pop(parts[1].strip(), None)
        _save_sessions()
    return {"status": "ok"}

# Эмоции агентов и лимиты ленты событий (чтобы не переполнять память и ответы)
EMOTIONS = ["happy", "sad", "angry", "neutral"]
EVENTS_MAX = 400   # в глобальном состоянии храним не более 400 событий
EVENTS_TAIL = 15   # в промпты и ответы клиенту отдаём последние 15


def update_emotion(current: str, event: str) -> str:
    event_lower = event.lower()
    if any(w in event_lower for w in ["good", "great", "happy", "nice", "love", "positive"]):
        return "happy"
    if any(w in event_lower for w in ["bad", "sorry", "fail", "angry", "hate", "negative"]):
        return random.choice(["sad", "angry"])
    return current


def _extract_llm_text(message) -> str:
    if not message or not hasattr(message, "content"):
        return ""
    content = message.content
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        all_texts = []
        for block in content:
            t = None
            if isinstance(block, dict):
                t = block.get("text") or block.get("content")
            elif hasattr(block, "text"):
                t = getattr(block, "text", None)
            if t and isinstance(t, str):
                all_texts.append(t)
        if all_texts:
            return all_texts[-1].strip()
        return ""
    return str(content).strip() if content else ""


def clean_message_to_russian(text: str) -> str:
    return re.sub(r"[^0-9\s\u0400-\u04FF.,!?;:()\"'«»\-]", "", text)


def apply_story_impact_to_moods(event_text: str) -> None:
    for agent in global_state["agents"].values():
        agent["mood"] = update_emotion(agent["mood"], event_text)

def emotion_influenced_prompt(base_prompt: str, emotion: str) -> str:
    style = ""
    if emotion == "happy":
        style = " Отвечай весело, позитивно, с восклицаниями и смайликами :)"
    elif emotion == "sad":
        style = " Отвечай грустно, меланхолично, с ноткой печали..."
    elif emotion == "angry":
        style = " Отвечай раздражённо, резко, можешь использовать CAPS и восклицательные знаки!!!"
    return base_prompt + style

# Граф отношений: вершины агенты (id), вес ребра симпатия -100..100 (для визуализации и логики)
relations_graph = nx.Graph()

def update_relationship(agent1: str, agent2: str, sympathy: int):
    relations_graph.add_edge(agent1, agent2, weight=sympathy)


# По ключевым словам в реплике определяем сдвиг отношения (+/-); используется в act()
def _message_sentiment_change(msg: str) -> int:
    if not msg or not isinstance(msg, str):
        return 0
    m = msg.lower().strip()
    positive = (
        "спасибо", "благодар", "класс", "круто", "здорово", "супер", "друг", "друзья", "люблю", "нравишься",
        "извини", "прости", "согласен", "поддерживаю", "молодец", "умничка", "красав", "отлично", "принято",
        "давай", "помогу", "рад", "рада", "хорошо", "норм", "нормально", "ок", "окей", "понял", "понятно"
    )
    negative = (
        "дурак", "идиот", "надоел", "надоело", "ненавижу", "отстань", "отвали", "зануда", "эгоист", "достал",
        "лицемер", "токсик", "бесишь", "раздражаешь", "плевать", "пофиг", "не люблю", "противно", "уйди",
        "врать", "врун", "предатель", "подлец", "гад", "мерзавец", "тупица", "дебил"
    )
    neg_count = sum(1 for w in negative if w in m)
    pos_count = sum(1 for w in positive if w in m)
    if neg_count > pos_count:
        return max(-4, -(neg_count - pos_count))
    if pos_count > neg_count:
        return min(4, pos_count - neg_count)
    return 0


def _cap_events():
    global global_state
    ev = global_state["events"]
    if len(ev) > EVENTS_MAX:
        global_state["events"] = ev[-EVENTS_MAX:]


def _parse_dialogue_event(ev: str):
    """Из строки вида 'Имя1 → Имя2: сообщение' возвращает (Имя1, Имя2) или None."""
    if " → " not in ev or ": " not in ev:
        return None
    left, rest = ev.split(" → ", 1)
    speaker = left.strip()
    right = rest.split(":", 1)[0].strip()
    listener = right
    if not speaker or not listener:
        return None
    return (speaker, listener)


def _events_between_pair(events: List[str], name_a: str, name_b: str) -> List[str]:
    """События только между двумя участниками (диалог A–B), без чужих реплик."""
    pair = {name_a, name_b}
    result = []
    for ev in events:
        parsed = _parse_dialogue_event(ev)
        if parsed is None:
            continue
        speaker, listener = parsed
        if {speaker, listener} == pair:
            result.append(ev)
    return result


def _message_from_dialogue_event(ev: str) -> str:
    """Из строки 'A → B: сообщение' возвращает только текст сообщения."""
    if ": " not in ev:
        return ""
    return ev.split(":", 1)[1].strip()


def _strip_agent_name_from_life_text(text: str, self_name: str) -> str:
    """Убирает имя агента в начале текста ([Жизнь] Лиза: Лиза: ... → только описание)."""
    if not text or not self_name:
        return text
    t = text.strip()
    for prefix in (self_name + ":", self_name + ",", self_name + " "):
        if t.startswith(prefix) or t.lower().startswith(prefix.lower()):
            t = t[len(prefix):].strip()
            break
    return t


def _is_same_reply_twice(old_msg: str, new_msg: str, min_common_chars: int = 20) -> bool:
    """Проверяет, не является ли new_msg повторением/исправлением old_msg (одна и та же реплика по смыслу)."""
    if not (old_msg and new_msg):
        return False
    a, b = old_msg.strip(), new_msg.strip()
    if a == b:
        return True
    if len(a) >= min_common_chars and len(b) >= min_common_chars:
        if a[:min_common_chars] == b[:min_common_chars]:
            return True
        if a in b or b in a:
            return True
        if min(len(a), len(b)) >= 35 and a[:35] == b[:35]:
            return True
    return False


def _life_text_same_theme(old_text: str, new_text: str, min_shared_words: int = 3) -> bool:
    """Проверяет, не повторяет ли новое [Жизнь]-действие ту же тему (общие слова/фразы)."""
    if not (old_text and new_text):
        return False
    a, b = old_text.strip().lower(), new_text.strip().lower()
    if a in b or b in a:
        return True
    if len(a) >= 25 and len(b) >= 25 and (a in b or b in a):
        return True
    # Общая длинная подстрока (например «пусть Лиза решит, приходить или нет»)
    for length in (30, 25, 20):
        if len(a) < length or len(b) < length:
            continue
        for i in range(len(a) - length + 1):
            sub = a[i : i + length]
            if sub in b:
                return True
    # Пересечение значимых слов (длина >= 3)
    def words(s: str):
        return set(re.findall(r"[а-яёa-z]{3,}", s.lower()))
    old_w, new_w = words(a), words(b)
    shared = old_w & new_w
    if len(shared) >= min_shared_words:
        return True
    if len(new_w) >= 4 and len(shared) >= min(len(new_w) * 2 // 5, 2):
        return True
    return False


def _strip_speaker_prefix(text: str, speaker_name: str) -> str:
    """Убирает подпись говорящего в начале реплики (например 'Лиза: ...')."""
    if not text or not speaker_name:
        return text
    msg = text.strip()
    prefixes = (
        speaker_name + ":",
        speaker_name + ",",
        speaker_name + " ",
        "Я, " + speaker_name + ",",
        "Я, " + speaker_name + " ",
    )
    while True:
        before = msg
        for prefix in prefixes:
            if msg.lower().startswith(prefix.lower()):
                msg = msg[len(prefix):].strip()
                break
        if msg == before:
            break
    return msg


def _is_allowed_name_form(token: str, allowed_names: List[str]) -> bool:
    """Проверяет, что имя из текста относится к известным участникам (с учётом простых склонений)."""
    t = (token or "").strip().lower()
    if not t:
        return False
    for name in allowed_names:
        n = (name or "").strip().lower()
        if not n:
            continue
        if t == n:
            return True
        # Простая эвристика для склонений: Лиза/Лизу/Лизе, Руслан/Руслана/Руслану
        root = n[:4] if len(n) >= 4 else n
        if root and t.startswith(root):
            return True
    return False


def _contains_unknown_name(text: str, allowed_names: List[str]) -> bool:
    """Находит упоминания неизвестных имён в середине предложений."""
    if not text:
        return False
    common_non_names = {
        "Ветер", "Парк", "Кафе", "Озеро", "Пруд", "Лес", "Город", "Дом", "Улица",
        "Сегодня", "Вечером", "Утром", "Ночью", "Сейчас", "Потом",
    }
    sentences = [s.strip() for s in re.split(r"[.!?]+", text) if s.strip()]
    for sentence in sentences:
        caps = re.findall(r"\b[А-ЯЁ][а-яё]{2,}\b", sentence)
        if not caps:
            continue
        # Первое слово предложения может быть обычным словом, его игнорируем
        for token in caps[1:]:
            if token in common_non_names:
                continue
            if not _is_allowed_name_form(token, allowed_names):
                return True
    return False


def _contains_unknown_person_reference(text: str, allowed_names: List[str]) -> bool:
    """Ловит обращения к неизвестным людям в формах после предлогов: к/у/с/для/от/про + имя."""
    if not text:
        return False
    low = text.lower()
    # Частые не-имена после предлогов (минимальный whitelist, чтобы не шуметь)
    non_person_words = {
        "двери", "дверь", "окну", "окна", "озеру", "озера", "пруду", "пруда",
        "парку", "парка", "бару", "бара", "стойке", "стойки", "дому", "дома",
        "улице", "улицы", "магазину", "магазина", "киоску", "киоска",
    }
    for m in re.finditer(r"\b(к|у|с|для|от|про|о)\s+([а-яё]{3,})\b", low):
        token = m.group(2)
        if token in non_person_words:
            continue
        if not _is_allowed_name_form(token, allowed_names):
            return True
    return False


def _has_obvious_grammar_issue(text: str) -> bool:
    """Грубые детекторы явно ломаной фразы (без полноценного парсера)."""
    if not text:
        return False
    t = text.strip()
    # Частая ошибка вида "сел напротив Марину"
    if re.search(r"\bнапротив\s+[А-ЯЁ][а-яё]+[ую]\b", t):
        return True
    # Повтор словосочетания через запятую/союз ("ветер ..., ветер ...")
    words = re.findall(r"[а-яё]{4,}", t.lower())
    if len(words) >= 8:
        dup = 0
        seen = set()
        for w in words:
            if w in seen:
                dup += 1
            else:
                seen.add(w)
        if dup >= 3:
            return True
    return False


def _contains_window_cliche(text: str) -> bool:
    """Шаблонные формулировки про окно, которые хотим вычищать из [Жизнь]."""
    if not text:
        return False
    t = text.lower()
    return bool(
        re.search(r"\bу\s+окн[ао]\b", t)
        or re.search(r"\bк\s+окн[ууе]\b", t)
        or re.search(r"\bвозле\s+окн[ао]\b", t)
        or re.search(r"\bу\s+окошк[аоуе]\b", t)
    )


def _needs_one_regen(candidate: str, recent_texts: List[str], allowed_names: List[str]) -> bool:
    """Решение, нужно ли сделать одну автоперегенерацию ответа."""
    txt = (candidate or "").strip()
    if not txt:
        return True
    if _contains_unknown_name(txt, allowed_names):
        return True
    if _contains_unknown_person_reference(txt, allowed_names):
        return True
    if _contains_window_cliche(txt):
        return True
    if _has_obvious_grammar_issue(txt):
        return True
    for old in recent_texts[-6:]:
        if _is_same_reply_twice(old, txt, 16) or _life_text_same_theme(old, txt, 3):
            return True
    return False


def _name_to_genitive(name: str) -> str:
    """Грубое склонение имени в родительный падеж (для частых конструкций типа '... не было')."""
    n = (name or "").strip()
    if not n:
        return n
    low = n.lower()
    if low.endswith("а"):
        prev = low[-2] if len(low) > 1 else ""
        return n[:-1] + ("и" if prev in ("г", "к", "х", "ж", "ч", "ш", "щ") else "ы")
    if low.endswith("я"):
        return n[:-1] + "и"
    if low.endswith("й"):
        return n[:-1] + "я"
    if low.endswith("ь"):
        return n[:-1] + "я"
    return n + "а"


def _fix_common_case_errors(text: str, allowed_names: List[str]) -> str:
    """Локальные автоправки частых падежных ошибок."""
    if not text:
        return text
    fixed = text
    for name in sorted(set(allowed_names), key=len, reverse=True):
        if not name:
            continue
        gen = _name_to_genitive(name)
        # "Ваня там не было" -> "Вани там не было"
        fixed = re.sub(
            rf"\b{re.escape(name)}\s+там\s+не\s+был[аоыи]?\b",
            f"{gen} там не было",
            fixed,
            flags=re.IGNORECASE,
        )
        # "... у стойки Ваня там не было" -> "... у стойки, Вани там не было"
        fixed = re.sub(
            rf"(\bу\s+[а-яё]+)\s+{re.escape(name)}\s+там\s+не\s+был[аоыи]?\b",
            rf"\1, {gen} там не было",
            fixed,
            flags=re.IGNORECASE,
        )
    return fixed


def _extract_location_tag(text: str) -> str:
    """Выделяет грубую метку локации из текста [Жизнь]."""
    if not text:
        return ""
    t = text.lower()
    location_map = {
        "бар": ("бар", "стойк"),
        "кафе": ("кафе",),
        "парк": ("парк",),
        "пруд": ("пруд",),
        "озеро": ("озеро",),
        "книжный_магазин": ("книжный магазин", "магазин", "комикс"),
        "магазин": ("магазин",),
        "улица": ("улица",),
        "дом": ("дом", "квартира"),
        "библиотека": ("библиотека",),
        "набережная": ("набережная",),
        "двор": ("двор",),
        "остановка": ("остановка",),
        "спортплощадка": ("спортплощадка", "стадион"),
        "рынок": ("рынок",),
        "подъезд": ("подъезд",),
        "офис": ("офис",),
    }
    for tag, keys in location_map.items():
        if any(k in t for k in keys):
            return tag
    return ""


def _too_fast_location_switch(recent_life_texts: List[str], new_life_text: str) -> bool:
    """Блокируем залипание в одной и той же локации подряд (а не смену мест)."""
    if not new_life_text or not recent_life_texts:
        return False
    new_loc = _extract_location_tag(new_life_text)
    if not new_loc:
        return False
    recent_locs = [loc for loc in (_extract_location_tag(txt) for txt in recent_life_texts[-2:]) if loc]
    if not recent_locs:
        return False
    return recent_locs[-1] == new_loc


def _has_transition_marker(text: str) -> bool:
    """Есть ли в тексте признак явного перемещения между локациями."""
    if not text:
        return False
    t = text.lower()
    markers = (
        "вышел", "вышла", "перешёл", "перешел", "перешла", "дошёл", "дошел", "дошла",
        "добрался", "добралась", "доехал", "доехала", "поехал", "поехала",
        "переместился", "переместилась", "направился", "направилась", "пошёл", "пошла",
        "после этого", "затем", "спустя", "через",
    )
    return any(m in t for m in markers)


def _is_abrupt_location_jump(recent_life_texts: List[str], new_life_text: str) -> bool:
    """Смена локации подряд без описанного перехода считается резким прыжком."""
    if not new_life_text or not recent_life_texts:
        return False
    new_loc = _extract_location_tag(new_life_text)
    if not new_loc:
        return False
    last_loc = ""
    for txt in reversed(recent_life_texts):
        loc = _extract_location_tag(txt)
        if loc:
            last_loc = loc
            break
    if not last_loc or last_loc == new_loc:
        return False
    return not _has_transition_marker(new_life_text)


def _is_location_overused_globally(events: List[str], new_life_text: str, max_hits: int = 2) -> bool:
    """Не даём всем агентам толпиться в одной локации в последние события."""
    new_loc = _extract_location_tag(new_life_text)
    if not new_loc:
        return False
    hits = 0
    for ev in events[-14:]:
        if not ev.startswith("[Жизнь] "):
            continue
        txt = ev.split(":", 1)[1].strip() if ":" in ev else ev
        if _extract_location_tag(txt) == new_loc:
            hits += 1
            if hits >= max_hits:
                return True
    return False


_LIFE_ACTION_STARTS = (
    "подошёл", "подошел", "посмотрел", "посмотрела", "прошёл", "прошел", "зашёл", "зашел",
    "сел", "села", "встал", "встала", "поднял", "подняла", "остановился", "остановилась",
    "пошёл", "пошла", "заметил", "заметила", "подошла", "прошла", "зашла", "пошла",
    "медленно прошёл", "медленно прошла", "подошел к", "подошла к", "прошёл к", "прошла к",
    "заглянул", "заглянула", "присел", "присела", "прилёг", "прилегла",
)


def _looks_like_life_action(text: str) -> bool:
    """Проверяет, похоже ли сообщение на описание действия/сцены (нужно оформить как [Жизнь], а не диалог)."""
    if not text or len(text) < 15:
        return False
    t = text.strip().lower()
    if t.startswith("[жизнь]") or t.startswith("жизнь "):
        return True
    for start in _LIFE_ACTION_STARTS:
        if t.startswith(start) or t.startswith(start.capitalize()):
            return True
    direct_address = ("ты ", "тебе ", "тебя ", "вам ", "вас ", "тобой ", "вами ")
    first_60 = t[:60]
    if any(d in first_60 for d in direct_address):
        return False
    if "?" in t[:50]:
        return False
    if len(t) >= 25 and (t.startswith("я ") or "подошёл" in t[:30] or "посмотрел" in t[:30] or "прошёл" in t[:30]):
        return True
    return False


def _last_speaker_to_agent(events: List[str], listener_display_name: str, agents: Dict) -> Optional[str]:
    """Кто последним писал этому агенту (по отображаемому имени). Возвращает id агента или None."""
    for ev in reversed(events):
        parsed = _parse_dialogue_event(ev)
        if not parsed:
            continue
        speaker_display, listener = parsed
        if listener != listener_display_name:
            continue
        for agent_id, data in agents.items():
            if (data.get("name") or agent_id) == speaker_display:
                return agent_id
    return None


def _state_payload():
    return {
        "events": global_state["events"][-EVENTS_TAIL:],
        "agents": global_state["agents"],
        "graph": [{"source": u, "target": v, "weight": d["weight"]} for u, v, d in relations_graph.edges(data=True)],
    }


# Типы для LangGraph: состояние одного агента и общее состояние симуляции
class AgentState(TypedDict):
    name: str
    personality: str
    mood: str
    memories: List[str]
    plans: str
    relations: Dict[str, int]
    gender: str

class GlobalState(TypedDict):
    agents: Dict[str, AgentState]
    events: Annotated[List[str], lambda x, y: x + y]
    user_input: str
    events_dedupe: Annotated[Optional[List[Tuple[str, str, str]]], lambda x, y: y if y else x]
    events_dedupe_life: Annotated[Optional[List[Tuple[str, str]]], lambda x, y: y if y else x]

# Узел графа: агенты формулируют краткий план на следующий шаг на основе личности, настроения, событий
async def reflect(state: GlobalState):
    reflect_n = max(1, int(os.getenv("REFLECT_AGENTS_PER_TICK", "2")))
    agent_ids = list(state["agents"].keys())
    random.shuffle(agent_ids)
    for agent_id in agent_ids[: min(reflect_n, len(agent_ids))]:
        agent = state["agents"][agent_id]
        name = agent_id
        display_name = agent.get("name", agent_id)
        previous_plan = agent.get("plans", "")
        prompt = ChatPromptTemplate.from_template(
            """Ты — {name} (один из участников симуляции). Твоя личность: {personality}.
Твой пол: {gender}.
Текущее настроение: {mood}.
Ключевые воспоминания: {memories}.
Недавние события: {events}.
Твой предыдущий план (для контекста, не повторяй его дословно): {previous_plan}

Дай себе одну короткую цель/план на следующий шаг (новый шаг, не повтор прошлого). Род — по полу. Только русский, кириллица, 1–2 предложения. Без приветствий."""
        )
        try:
            response = await run_llm_text(prompt, {
                "name": display_name,
                "personality": agent["personality"],
                "gender": agent["gender"],
                "mood": agent["mood"],
                "memories": "\n".join(agent["memories"][-5:]),
                "events": "\n".join(state["events"][-5:]),
                "previous_plan": previous_plan or "плана ещё не было",
            })
            new_plan = clean_message_to_russian(response.strip())

            if previous_plan and new_plan and new_plan == previous_plan:
                alt_prompt = ChatPromptTemplate.from_template(
                    """Ты — {name} (один из участников). Твоя личность: {personality}.
Твой пол: {gender}.
Текущее настроение: {mood}.
Ключевые воспоминания: {memories}.
Недавние события: {events}.
Твой прошлый план был таким (НЕ ПОВТОРЯЙ ЕГО): {previous_plan}

Придумай принципиально НОВЫЙ план/цель на следующие действия, который двигает историю вперёд.
Не используй китайский язык и другие алфавиты, пиши только по‑русски (кириллицей), без английских слов.
Сформулируй 1–3 коротких предложения разговорным русским."""
                )
                alt_response = await run_llm_text(alt_prompt, {
                    "name": display_name,
                    "personality": agent["personality"],
                    "gender": agent["gender"],
                    "mood": agent["mood"],
                    "memories": "\n".join(agent["memories"][-5:]),
                    "events": "\n".join(state["events"][-5:]),
                    "previous_plan": previous_plan,
                })
                alt_plan = clean_message_to_russian(alt_response.strip())
                if alt_plan and alt_plan != previous_plan:
                    new_plan = alt_plan

            agent["plans"] = new_plan or previous_plan
        except Exception as e:
            print(f"LLM error in reflect for {display_name}: {e}")
            if not agent.get("plans"):
                agent["plans"] = "План временно недоступен — ИИ перегружен, использую своё прежнее направление."
    return state

# Узел графа: агенты по очереди генерируют реплики друг другу, обновляют отношения и граф, добавляют события
async def act(state: GlobalState):
    new_events = []
    agent_names = list(state["agents"].keys())
    all_events = state["events"]
    interactions = max(1, int(os.getenv("INTERACTIONS_PER_TICK", "3")))

    if len(agent_names) < 2:
        return state

    current_events = list(state["events"])
    participant_names = sorted(
        [(state["agents"][aid].get("name") or aid) for aid in agent_names],
        key=lambda x: x.lower(),
    )
    all_participants = ", ".join(participant_names)
    allowed_names = participant_names + ["Игрок"]
    # Если последнее событие — сообщение игрока, два агента отвечают игроку (заметная реакция на чат)
    if current_events and current_events[-1].startswith("[Игрок]:"):
        player_msg = current_events[-1].split(":", 1)[1].strip() if ":" in current_events[-1] else current_events[-1].replace("[Игрок]:", "").strip()
        recent_context = "\n".join(current_events[-6:]) if len(current_events) > 1 else "Событий пока мало."
        responder_ids = random.sample(agent_names, min(2, len(agent_names)))
        new_player_events = []
        for name in responder_ids:
            agent = state["agents"][name]
            self_name = agent.get("name", name)
            player_response_prompt = ChatPromptTemplate.from_template(
                """Ты — {name}. Твоя личность: {personality}. Твой пол: {gender}. Настроение: {mood}.

Недавний контекст в чате:
{recent_context}

Доступные участники симуляции: {participants}. Не придумывай новых имён и персонажей.

Человек (игрок) только что написал в общий чат: «{player_msg}»

Важно: отреагируй именно на его сообщение — ответь на вопрос, прокомментируй, предложи помощь или выскажи короткое мнение. Не общие фразы вроде «продолжаю» — именно реакция на то, что он сказал.
Пиши грамматически корректно: проверяй падежи и окончания.
Одна короткая реплика. Только русский. Без приветствий и подписи."""
            )
            try:
                reply = await run_llm_text(player_response_prompt, {
                    "name": self_name,
                    "personality": agent.get("personality", ""),
                    "gender": agent.get("gender", "человек"),
                    "mood": agent.get("mood", "neutral"),
                    "player_msg": player_msg[:500],
                    "recent_context": recent_context[:800],
                    "participants": all_participants[:300],
                })
                reply = _strip_speaker_prefix((reply or "").strip(), self_name) or "Понял."
                reply = _fix_common_case_errors(reply, allowed_names)
                recent_self_msgs = []
                for ev in current_events[-20:]:
                    parsed = _parse_dialogue_event(ev)
                    if not parsed:
                        continue
                    sp, _ = parsed
                    if sp != self_name:
                        continue
                    old_msg = _message_from_dialogue_event(ev)
                    if old_msg:
                        recent_self_msgs.append(old_msg)
                if _needs_one_regen(reply, recent_self_msgs, allowed_names):
                    try:
                        reply_retry = await run_llm_text(player_response_prompt, {
                            "name": self_name,
                            "personality": agent.get("personality", ""),
                            "gender": agent.get("gender", "человек"),
                            "mood": agent.get("mood", "neutral"),
                            "player_msg": player_msg[:500],
                            "recent_context": recent_context[:800],
                            "participants": all_participants[:300],
                        })
                        reply_retry = _strip_speaker_prefix((reply_retry or "").strip(), self_name)
                        if reply_retry:
                            reply = _fix_common_case_errors(reply_retry, allowed_names)
                    except Exception:
                        pass
                event_text = f"{self_name} → Игрок: {reply}"
                if _contains_unknown_name(reply, allowed_names) or _contains_unknown_person_reference(reply, allowed_names):
                    reply = "Слушаю тебя, давай разберёмся."
                    event_text = f"{self_name} → Игрок: {reply}"
                agent["memories"] = agent.get("memories", []) + [event_text]
                new_player_events.append(event_text)
            except Exception as e:
                print(f"LLM error in act (response to player) for {name}: {e}")
        if new_player_events:
            out = {
                "agents": state["agents"],
                "user_input": state.get("user_input", ""),
                "events": new_player_events,
            }
            return out

    # При 3+ агентах: за тик говорят не более 2 агентов, каждый — одному случайному. Диалоги парные (A↔B, C↔D), контекст по каждой паре свой.
    speakers = agent_names[:]
    random.shuffle(speakers)
    max_speakers = interactions if len(agent_names) <= 2 else min(interactions, 2)
    speakers = speakers[: min(max_speakers, len(speakers))]

    delay_between_messages = (float(os.getenv("ACT_DELAY_MIN_SEC", "5")), float(os.getenv("ACT_DELAY_MAX_SEC", "7")))
    dedupe_list: List[Tuple[str, str, str]] = []
    dedupe_life_list: List[Tuple[str, str]] = []

    used_pairs = set()  # не даём одному агенту за тик говорить двум разным (меньше путаницы)
    for idx, name in enumerate(speakers):
        agent = state["agents"][name]
        self_name = agent.get("name", name)
        candidates = [n for n in agent_names if n != name]
        available = [n for n in candidates if (name, n) not in used_pairs]
        if not available:
            available = candidates
        # Приоритет: ответить тому, кто последним писал этому агенту (чтобы не путать адресата)
        last_to_me = _last_speaker_to_agent(current_events, self_name, state["agents"])
        if last_to_me and last_to_me in available:
            other = last_to_me
        else:
            other = random.choice(available)
        used_pairs.add((name, other))
        other_agent = state["agents"][other]
        other_display = other_agent.get("name", other)

        # Контекст только этого диалога (пара A–B), чтобы при 3+ агентах не путать сюжет
        pair_events = _events_between_pair(current_events[-20:], self_name, other_display)
        recent_events = "\n".join(pair_events[-10:]) if pair_events else "В этом диалоге пока мало реплик."

        relation_score = agent["relations"].get(other, 0)
        gender_self = (agent.get("gender") or "").strip().lower()
        gender_other = (other_agent.get("gender") or "").strip().lower()
        male = ("мужчина", "м", "male", "мужской")
        female = ("женщина", "ж", "female", "женский")
        same_sex = (
            (gender_self in male and gender_other in male)
            or (gender_self in female and gender_other in female)
        )

        if same_sex:
            relation_score_for_tone = min(relation_score, 55)
        else:
            relation_score_for_tone = relation_score

        if relation_score_for_tone >= 60:
            relation_tone = (
                "Ты очень хорошо относишься к собеседнику: говори тепло, по‑дружески, "
                "с поддержкой и шутками."
            )
        elif relation_score_for_tone >= 20:
            relation_tone = (
                "Ты относишься к собеседнику скорее положительно: будь доброжелателен, "
                "можешь подшучивать"
            )
        elif relation_score_for_tone <= -60:
            relation_tone = (
                "Ты очень плохо относишься к собеседнику: говори резко, холодно, с колкими, "
                "иногда используя обидные, но НЕ матерные выражения (например: 'зануда', 'эгоист', 'достал', 'лицемер', 'токсик'). "
                "Строго без мата и без жестоких унижений."
            )
        elif relation_score_for_tone <= -20:
            relation_tone = (
                "Ты относишься к собеседнику плохо: говори сухо, с сарказмом, "
                "можешь задеть его словами (без мата и без жёстких оскорблений)."
            )
        else:
            relation_tone = (
                "Ты относишься к собеседнику нейтрально: говори спокойно, обычным тоном, "
                "без лишней теплоты и без открытой агрессии."
            )

        same_sex_rule = ""
        if same_sex:
            same_sex_rule = (
                "\nСтрогое ограничение: ты и собеседник одного пола. "
                "Запрещены любовные, романтические, флиртующие реплики и намёки. "
                "Только дружеский или нейтральный тон, без романтики."
            )

        use_name_flag = "да" if random.random() < 0.22 else "нет"

        last_from_other = []
        for ev in pair_events[-15:]:
            parsed = _parse_dialogue_event(ev)
            if not parsed:
                continue
            speaker, listener = parsed
            if speaker != other_display or listener != self_name:
                continue
            try:
                msg_part = ev.split(":", 1)[1].strip() if ":" in ev else ev
                if msg_part:
                    last_from_other.append(msg_part)
            except IndexError:
                pass
        last_from_other = last_from_other[-3:]
        last_other_block = ""
        if last_from_other:
            verb_other = "говорила" if gender_other in female else "говорил"
            last_other_block = f"\nПоследнее, что {other_display} {verb_other} в этом диалоге (ответь по существу, продолжай тему):\n" + "\n".join(f"- {m}" for m in last_from_other) + "\n"

        my_recent = []
        for ev in pair_events[-12:]:
            parsed = _parse_dialogue_event(ev)
            if not parsed:
                continue
            speaker, listener = parsed
            if speaker != self_name or listener != other_display:
                continue
            try:
                msg_part = ev.split(":", 1)[1].strip() if ":" in ev else ev
                if msg_part and msg_part not in my_recent:
                    my_recent.append(msg_part)
            except IndexError:
                pass
        my_recent = my_recent[-4:]
        # Все недавние реплики этого агента кому угодно — чтобы не повторять одну тему (мемы, коты и т.д.)
        my_recent_any = []
        for ev in current_events[-25:]:
            parsed = _parse_dialogue_event(ev)
            if not parsed:
                continue
            speaker, _ = parsed
            if speaker != self_name:
                continue
            try:
                msg_part = ev.split(":", 1)[1].strip() if ":" in ev else ev
                if msg_part and msg_part not in my_recent_any:
                    my_recent_any.append(msg_part)
            except IndexError:
                pass
        my_recent_any = my_recent_any[-6:]
        avoid_repeat_block = ""
        if my_recent:
            avoid_repeat_block = f"\nТвои недавние реплики в этом диалоге (НЕ повторяй их):\n" + "\n".join(f"- {m}" for m in my_recent) + "\n"
        if my_recent_any:
            avoid_repeat_block += f"\nТвои недавние реплики разным людям — НЕ повторяй темы и формулировки (например не пиши подряд одно и то же про мемы, котов, скинул в чат и т.д.):\n" + "\n".join(f"- {m}" for m in my_recent_any) + "\n"

        gender_agreement = (
            "Согласуй род с полом собеседника: когда упоминаешь его/её слова или действия — "
            "если собеседник женщина: «сказала», «была», «пошла»; если мужчина: «сказал», «был», «пошёл»."
        )
        # В [Жизнь] — род по своему полу: женщина → вытащила, позвонила; мужчина → вытащил, позвонил
        life_self_gender = (
            "В действиях [Жизнь] описывай себя в женском роде: вытащила, набрала, позвонила, пошла, села, зашла (ты женщина)."
            if gender_self in female else
            "В действиях [Жизнь] описывай себя в мужском роде: вытащил, набрал, позвонил, пошёл, сел, зашёл (ты мужчина)."
        )
        location_rule = (
            "Локации и контакт: (1) Если ты и собеседник в разных местах (один у пруда, другой в баре и т.п.) — "
            "не пиши ему/ей реплику. Напиши ОДНО предложение о своём действии и начни его ровно с [Жизнь] (со скобками). "
            + life_self_gender + " "
            "Выбирай разнообразные места: библиотека, набережная, двор, остановка, рынок, подъезд, офис, книжный магазин. "
            "Запрещён шаблон «сел(а) у окна / у окошка / к окну», не повторяй локацию из последних событий ленты. "
            "Если меняешь локацию относительно предыдущего действия, обязательно укажи переход (например: вышел(а), дошёл/дошла, затем, спустя, перешёл/перешла). "
            "Например: если ты женщина — [Жизнь] Проверила расписание на остановке и пошла к набережной. "
            "Если мужчина — [Жизнь] Зашёл в книжный, пролистал комикс и вышел во двор. "
            "В реплике собеседнику слово «Жизнь» не пиши. "
            "(2) Если вы в одном месте или встретились — пиши обычную реплику собеседнику, без [Жизнь] и без слова «Жизнь» в начале."
        )
        # Чтобы не плодить одинаковые [Жизнь] (типа «скамейка у пруда» раз за разом)
        recent_life_self = [m for m in agent.get("memories", []) if m.startswith(f"[Жизнь] {self_name}:")][-3:]
        recent_life_block = ""
        if recent_life_self:
            recent_life_block = "\nТвои недавние действия [Жизнь] (НЕ повторяй то же место и то же занятие — придумай другое действие или другую локацию):\n" + "\n".join(f"- {m}" for m in recent_life_self) + "\n"

        base_prompt = f"""Ты — {self_name}. Сейчас в этом сообщении участвуют только ты и {other_display} (диалог один на один). Пиши реплику только ему/ей.
Твоя личность: {agent['personality']}. Твой пол: {agent.get('gender', 'человек')}. Пол собеседника: {other_agent.get('gender', 'человек')}.
Твой план: {agent['plans']}. Отношения с {other_display}: {relation_score}. {relation_tone}.{same_sex_rule}
Доступные участники симуляции: {all_participants}. Не придумывай новых имён и новых персонажей.

Недавний контекст разговора (хронология):
{recent_events or "Событий пока мало."}
{last_other_block}
{avoid_repeat_block}
{recent_life_block}
{gender_agreement}
{location_rule}

Строго: реплика в диалоге (A → B) — только слова, которые ты говоришь собеседнику. Не смешивай действие и сообщение в одной строке (нельзя: «Записал в блокнот. Ваня ищет пиццу» — либо только твои слова ему/ей, либо отдельно [Жизнь]-действие). Либо чистая реплика, либо [Жизнь]-действие — одно из двух.

Задание: одно предложение. Если вы в одном месте/встретились — только реплика {other_display} (только то, что говоришь, без описания своих действий). Если в разных местах — только описание своего действия, строго начиная с [Жизнь] (со скобками); не повторяй свои последние [Жизнь]-действия и не пиши в начале своё имя (например «Лиза:»).
Твоя реплика должна логично продолжать разговор. Флаг имени: {use_name_flag}. Род по полу. Только русский. Коротко и по делу.
Пиши грамматически корректно: проверяй падежи и окончания.
Не пиши в начале реплики своё имя. Только текст сообщения, без подписи."""
        
        full_prompt = emotion_influenced_prompt(base_prompt, agent["mood"])
        prompt = ChatPromptTemplate.from_template(full_prompt)
        try:
            message = await run_llm_text(prompt, {})
        except Exception as e:
            print(f"LLM error in act for {name}: {e}")
            message = f"ИИ недоступен, но {name} продолжает обдумывать отношения с {other} без подсказок модели."
        if not (message or "").strip():
            message = "(сообщение не сгенерировано — проверь формат ответа модели)"
        message = _strip_speaker_prefix((message or "").strip(), self_name) or message
        message = _fix_common_case_errors(message, allowed_names)
        if _needs_one_regen(message, my_recent_any, allowed_names):
            try:
                message_retry = await run_llm_text(prompt, {})
                message_retry = _strip_speaker_prefix((message_retry or "").strip(), self_name)
                if message_retry:
                    message = _fix_common_case_errors(message_retry, allowed_names)
            except Exception:
                pass

        msg_raw = (message or "").strip()
        if msg_raw.upper().startswith("[ЖИЗНЬ]"):
            life_text = msg_raw[7:].strip()
        elif msg_raw.startswith("Жизнь ") or msg_raw.startswith("жизнь "):
            life_text = msg_raw[6:].strip()
        elif _looks_like_life_action(msg_raw):
            life_text = msg_raw
        else:
            life_text = None
        if life_text:
            life_text = _strip_agent_name_from_life_text(life_text, self_name)
            life_text = _fix_common_case_errors(life_text, participant_names)
            recent_life_evs = [ev for ev in current_events if ev.startswith("[Жизнь] " + self_name + ":")][-2:]
            recent_life_texts = [
                (ev.split(":", 1)[1].strip() if ":" in ev else "")
                for ev in recent_life_evs
            ]
            if (
                _needs_one_regen(life_text, recent_life_texts, participant_names)
                or _too_fast_location_switch(recent_life_texts, life_text)
                or _is_abrupt_location_jump(recent_life_texts, life_text)
                or _is_location_overused_globally(current_events, life_text, 1)
            ):
                try:
                    life_retry_raw = await run_llm_text(prompt, {})
                    life_retry_msg = _strip_speaker_prefix((life_retry_raw or "").strip(), self_name)
                    if life_retry_msg.upper().startswith("[ЖИЗНЬ]"):
                        life_retry = life_retry_msg[7:].strip()
                    elif life_retry_msg.startswith("Жизнь ") or life_retry_msg.startswith("жизнь "):
                        life_retry = life_retry_msg[6:].strip()
                    elif _looks_like_life_action(life_retry_msg):
                        life_retry = life_retry_msg
                    else:
                        life_retry = ""
                    life_retry = _strip_agent_name_from_life_text(life_retry, self_name)
                    life_retry = _fix_common_case_errors(life_retry, participant_names)
                    if life_retry:
                        life_text = life_retry
                except Exception:
                    pass
            life_event = f"[Жизнь] {self_name}: {life_text}"
            skip_life = False
            if (
                _contains_unknown_name(life_text, participant_names)
                or _contains_unknown_person_reference(life_text, participant_names)
                or _contains_window_cliche(life_text)
                or _is_abrupt_location_jump(recent_life_texts, life_text)
                or _is_location_overused_globally(current_events, life_text, 1)
            ):
                skip_life = True
            for last_life in recent_life_evs:
                if last_life.count(":", 1) < 1:
                    continue
                old_life_msg = last_life.split(":", 1)[1].strip()
                if _is_same_reply_twice(old_life_msg, life_text) or _life_text_same_theme(old_life_msg, life_text):
                    dedupe_life_list.append((self_name, life_event))
                    skip_life = True
                    break
            if not skip_life:
                agent["mood"] = update_emotion(agent["mood"], life_text)
                agent["memories"].append(life_event)
                new_events.append(life_event)
                current_events.append(life_event)
                apply_story_impact_to_moods(life_event)
                await broadcast_state_override(current_events, state["agents"])
            if idx < len(speakers) - 1:
                await asyncio.sleep(random.uniform(delay_between_messages[0], delay_between_messages[1]))
            continue

        # Говорящий: сдвиг отношения от тональности своей реплики (или случайный при нейтральной)
        change = _message_sentiment_change(message or "")
        if change == 0:
            change = random.randint(-1, 1)
        old_sym = agent["relations"].get(other, 0)
        new_sym = max(-100, min(100, old_sym + change))
        if same_sex:
            new_sym = min(new_sym, 60)
        agent["relations"][other] = new_sym

        # Слушающий: своя реакция на реплику (не копируем change), чтобы отношения могли расходиться
        if change != 0:
            other_change = change + random.randint(-2, 2)
        else:
            other_change = random.randint(-1, 1)
        other_old = other_agent["relations"].get(name, 0)
        other_new = max(-100, min(100, other_old + other_change))
        if same_sex:
            other_new = min(other_new, 60)
        other_agent["relations"][name] = other_new

        avg_sym = (new_sym + other_new) // 2
        update_relationship(name, other, avg_sym)

        event_text = f"{self_name} → {other_display}: {message}"
        if _contains_unknown_name(message, participant_names) or _contains_unknown_person_reference(message, participant_names):
            if idx < len(speakers) - 1:
                await asyncio.sleep(random.uniform(delay_between_messages[0], delay_between_messages[1]))
            continue
        agent["mood"] = update_emotion(agent["mood"], message)

        pair_events_now = _events_between_pair(current_events, self_name, other_display)
        last_from_self = pair_events_now[-1] if pair_events_now else None
        if last_from_self:
            old_msg = _message_from_dialogue_event(last_from_self)
            if _is_same_reply_twice(old_msg, message):
                if last_from_self in agent["memories"]:
                    agent["memories"].remove(last_from_self)
                dedupe_list.append((self_name, other_display, event_text))
                if idx < len(speakers) - 1:
                    await asyncio.sleep(random.uniform(delay_between_messages[0], delay_between_messages[1]))
                continue
        # Не повторять одну и ту же реплику/тему разным людям (например «скинул мем с котом» и Лизи, и Руслану)
        same_to_other = False
        for ev in current_events[-20:]:
            parsed = _parse_dialogue_event(ev)
            if not parsed:
                continue
            sp, _ = parsed
            if sp != self_name:
                continue
            old_msg = _message_from_dialogue_event(ev)
            if old_msg and (
                _is_same_reply_twice(old_msg, message, 18)
                or _life_text_same_theme(old_msg, message, 3)
            ):
                same_to_other = True
                break
        if same_to_other:
            dedupe_list.append((self_name, other_display, event_text))
            if idx < len(speakers) - 1:
                await asyncio.sleep(random.uniform(delay_between_messages[0], delay_between_messages[1]))
            continue

        if vector_db is not None:
            try:
                from langchain_core.documents import Document
                doc = Document(page_content=event_text)
                vector_db.add_documents([doc])
            except Exception as e:
                print(f"Embeddings error for memory of {name}: {e}")
        agent["memories"].append(event_text)
        new_events.append(event_text)
        current_events.append(event_text)
        await broadcast_state_override(current_events, state["agents"])
        if idx < len(speakers) - 1:
            await asyncio.sleep(random.uniform(delay_between_messages[0], delay_between_messages[1]))

        _life_prob = float(os.getenv("LIFE_EVENT_PROBABILITY", "0.45"))
        if _life_prob > 0 and random.random() < _life_prob:
            life_prompt = ChatPromptTemplate.from_template(
                """Ты — {name}. Твоя личность: {personality}.
Твой пол: {gender}. Текущее настроение: {mood}.
Твой план: {plan}.
Доступные участники симуляции: {participants}. Не придумывай новых имён и новых персонажей.
С кем ты только что общался: {other_name}. Уровень отношений с ним: {relation_score}.
Твоё последнее сообщение ему: {last_message}
Недавние события сюжета вокруг вас: {events}.
Твои последние действия [Жизнь] (НЕ повторяй то же место и то же занятие — если недавно уже были парк/бар/пруд, выбери другую локацию): {recent_life}

Теперь опиши ОДНО короткое действие из твоей жизни (не сообщение другому персонажу), которое логично продолжает текущую ситуацию. Важно: не копируй свои недавние действия — смени место или занятие.
Используй разнообразные локации: библиотека, набережная, двор, остановка, рынок, подъезд, офис, книжный магазин. Не залипай в «парке/баре». Запрещены клише «у окна/у окошка/к окну». Если в последних событиях уже была эта локация — выбери другую.
Если меняешь локацию по сравнению с предыдущим действием, явно покажи переход (вышел(а), дошёл/дошла, затем, спустя, перешёл/перешла).
Строго: не пиши в начале своё имя (например «Лиза:»). Только описание действия. Согласуй род с твоим полом: если ты женщина — глаголы в прошедшем времени в женском роде (вытащила, позвонила, пошла, села, набрала). Если мужчина — в мужском (вытащил, позвонил, пошёл, сел, набрал). Запрещено повторять одну и ту же тему подряд: телефон, уведомления, звонки, бег к пруду, скамейка — смени сферу действия.
Пиши грамматически корректно: проверяй падежи и окончания.
Пиши 1–2 предложения. Без приветствий и обращений. Только по‑русски (кириллицей), без английских слов и без китайского."""
            )
            try:
                recent_life = " | ".join(
                    [m for m in agent.get("memories", []) if m.startswith("[Жизнь]")][-3:]
                )
                life_raw = await run_llm_text(life_prompt, {
                    "name": self_name,
                    "personality": agent["personality"],
                    "gender": agent.get("gender", "человек"),
                    "mood": agent["mood"],
                    "plan": agent.get("plans", "") or "плана пока нет",
                    "participants": all_participants[:300],
                    "other_name": other_display,
                    "relation_score": relation_score,
                    "last_message": message,
                    "events": recent_events or "Событий пока мало, обычный день.",
                    "recent_life": recent_life or "действий пока мало",
                })
                life_text = clean_message_to_russian(life_raw.strip())
                if life_text:
                    life_text = _strip_agent_name_from_life_text(life_text, self_name)
                    life_text = _fix_common_case_errors(life_text, participant_names)
                    # Не добавлять, если слишком похоже на недавнее действие этого агента (по тексту или по теме)
                    recent_life_evs = [ev for ev in current_events if ev.startswith(f"[Жизнь] {self_name}:")][-2:]
                    def _old_text(ev):
                        return ev.split(":", 1)[1].strip() if ":" in ev else ""
                    recent_life_texts = [_old_text(ev) for ev in recent_life_evs]
                    if (
                        _needs_one_regen(life_text, recent_life_texts, participant_names)
                        or _too_fast_location_switch(recent_life_texts, life_text)
                        or _is_abrupt_location_jump(recent_life_texts, life_text)
                        or _is_location_overused_globally(current_events, life_text, 1)
                    ):
                        try:
                            life_retry_raw = await run_llm_text(life_prompt, {
                                "name": self_name,
                                "personality": agent["personality"],
                                "gender": agent.get("gender", "человек"),
                                "mood": agent["mood"],
                                "plan": agent.get("plans", "") or "плана пока нет",
                                "participants": all_participants[:300],
                                "other_name": other_display,
                                "relation_score": relation_score,
                                "last_message": message,
                                "events": recent_events or "Событий пока мало, обычный день.",
                                "recent_life": " | ".join(recent_life_texts) if recent_life_texts else "действий пока мало",
                            })
                            life_retry = _strip_agent_name_from_life_text(
                                clean_message_to_russian((life_retry_raw or "").strip()),
                                self_name,
                            )
                            life_retry = _fix_common_case_errors(life_retry, participant_names)
                            if life_retry:
                                life_text = life_retry
                        except Exception:
                            pass
                    if recent_life_evs and any(
                        _is_same_reply_twice(_old_text(ev), life_text, 12) or _life_text_same_theme(_old_text(ev), life_text)
                        for ev in recent_life_evs
                    ):
                        pass  # пропускаем повтор
                    else:
                        if (
                            _contains_unknown_name(life_text, participant_names)
                            or _contains_unknown_person_reference(life_text, participant_names)
                            or _contains_window_cliche(life_text)
                            or _is_abrupt_location_jump(recent_life_texts, life_text)
                            or _is_location_overused_globally(current_events, life_text, 1)
                        ):
                            pass  # пропускаем неизвестные обращения к несуществующим персонажам
                        else:
                            life_event = f"[Жизнь] {self_name}: {life_text}"
                            agent["memories"].append(life_event)
                            new_events.append(life_event)
                            current_events.append(life_event)
                            apply_story_impact_to_moods(life_event)
            except Exception as e:
                print(f"LLM error in life event for {name}: {e}")

        if len(agent["memories"]) > 12:
            sum_prompt = ChatPromptTemplate.from_template(
                "Суммаризируй эти воспоминания в 3–5 предложений на русском языке, сохранив самое важное. Не используй английский язык.\n{mem}"
            )
            try:
                summary = (await run_llm_text(sum_prompt, {"mem": "\n".join(agent["memories"])})).strip()
                agent["memories"] = [summary] + agent["memories"][-3:]
            except Exception as e:
                print(f"LLM error in summarize memories for {name}: {e}")

        if idx < len(speakers) - 1:
            await asyncio.sleep(random.uniform(delay_between_messages[0], delay_between_messages[1]))

    out: Dict = {
        "agents": state["agents"],
        "user_input": state.get("user_input", ""),
        "events": new_events,
    }
    if dedupe_list:
        out["events_dedupe"] = dedupe_list
    if dedupe_life_list:
        out["events_dedupe_life"] = dedupe_life_list
    return out

# LangGraph: цепочка reflect, act за один тик симуляции; при каждом invoke состояние обновляется
workflow = StateGraph(GlobalState)
workflow.add_node("reflect", reflect)
workflow.add_node("act", act)
workflow.add_edge(START, "reflect")
workflow.add_edge("reflect", "act")
workflow.add_edge("act", END)
graph = workflow.compile()

# Глобальное состояние симуляции (общее для всех клиентов); начальные агенты для демо
global_state = {
    "agents": {
        "1": {
            "name": "Лиза",
            "personality": "Красивая девушка",
            "mood": "neutral",
            "memories": [],
            "plans": "",
            "relations": {},
            "gender": "женщина",
        },
        "2": {
            "name": "Ваня",
            "personality": "Прикольный чел",
            "mood": "neutral",
            "memories": [],
            "plans": "",
            "relations": {},
            "gender": "мужчина",
        },
        "3": {
            "name": "Руслан",
            "personality": "Душнила",
            "mood": "neutral",
            "memories": [],
            "plans": "",
            "relations": {},
            "gender": "мужчина",
        },
    },
    "events": [],
    "user_input": "",
    "events_dedupe": None,
    "events_dedupe_life": None,
}

# Фоновая задача: раз в N секунд прогоняем граф и рассылаем состояние всем подключённым WebSocket-клиентам
def _apply_events_dedupe():
    global global_state
    dedupe = global_state.get("events_dedupe") or []
    for (actor, listener, new_ev) in dedupe:
        ev = global_state["events"]
        for i in range(len(ev) - 1, -1, -1):
            if ev[i].startswith(actor + " → " + listener + ":"):
                ev.pop(i)
                break
        ev.append(new_ev)
    dedupe_life = global_state.get("events_dedupe_life") or []
    for (name, new_ev) in dedupe_life:
        ev = global_state["events"]
        prefix = "[Жизнь] " + name + ":"
        for i in range(len(ev) - 1, -1, -1):
            if ev[i].startswith(prefix):
                ev.pop(i)
                break
        ev.append(new_ev)
    if dedupe or dedupe_life:
        global_state["events_dedupe"] = []
        global_state["events_dedupe_life"] = []
        _cap_events()


async def simulate():
    global global_state
    interval = float(os.getenv("SIMULATION_INTERVAL_SECONDS", "1.2"))
    while True:
        try:
            global_state = await graph.ainvoke(global_state)
            _apply_events_dedupe()
            _cap_events()
            await broadcast_state()
        except Exception as e:
            print(f"Error in simulate loop: {e}")
        await asyncio.sleep(interval)


# Все активные WebSocket-подключения (один список на весь сервер)
connections: List[WebSocket] = []


async def broadcast_state():
    state_data = _state_payload()
    for ws in connections[:]:
        try:
            await ws.send_json(state_data)
        except:
            connections.remove(ws)


async def broadcast_state_override(events: List[str], agents: Dict):
    """Рассылает клиентам произвольное состояние (для порепликовой отдачи с задержкой)."""
    state_data = {
        "events": events[-EVENTS_TAIL:],
        "agents": agents,
        "graph": [{"source": u, "target": v, "weight": d["weight"]} for u, v, d in relations_graph.edges(data=True)],
    }
    for ws in connections[:]:
        try:
            await ws.send_json(state_data)
        except Exception:
            connections.remove(ws)


# REST API
# GET /state: текущее состояние симуляции (агенты, последние события, граф)
@app.get("/state")
def get_state():
    return _state_payload()

# WebSocket /ws: клиент подключается, получает рассылку состояния; сообщения от пользователя добавляются в события и запускают один проход графа
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    global global_state
    await websocket.accept()
    connections.append(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            event_text = f"[Игрок]: {data}"
            global_state["events"].append(event_text)
            apply_story_impact_to_moods(event_text)
            _cap_events()
            await broadcast_state()

            async def run_graph_then_broadcast():
                global global_state
                try:
                    global_state = await graph.ainvoke(global_state)
                    _apply_events_dedupe()
                    _cap_events()
                except Exception as e:
                    print(f"Error in graph invoke after user input: {e}")
                await broadcast_state()
            asyncio.create_task(run_graph_then_broadcast())
    except WebSocketDisconnect:
        pass
    except RuntimeError as e:
        if "accept" not in str(e).lower():
            raise
    finally:
        if websocket in connections:
            connections.remove(websocket)

@app.get("/agents/{name}")
def get_agent(name: str):
    return global_state["agents"].get(name, {})

# POST /event: добавить текстовое событие в ленту (влияет на настроение агентов и следующий шаг графа)
@app.post("/event")
async def add_event(event: Dict):
    global global_state
    text = event.get("text", "")
    event_text = f"[Событие]: {text}"
    global_state["events"].append(event_text)
    apply_story_impact_to_moods(event_text)
    try:
        global_state = await graph.ainvoke(global_state)
        _apply_events_dedupe()
        _cap_events()
    except Exception as e:
        print(f"Error in graph invoke after /event: {e}")
    return {"status": "added"}


@app.get("/graph")
def get_graph():
    return [{"source": u, "target": v, "weight": d["weight"]} for u, v, d in relations_graph.edges(data=True)]


@app.get("/history")
def get_history(limit: int = 200):
    return {"events": global_state["events"][-limit:]}


# Установка уровня отношения между двумя агентами (панель управления на фронте)
@app.post("/relations")
async def set_relation(rel: Dict):
    global global_state
    src = rel.get("source")
    tgt = rel.get("target")
    if not src or not tgt or src == tgt:
        raise HTTPException(status_code=400, detail="Нужно указать двух разных агентов.")

    agents = global_state["agents"]
    if src not in agents or tgt not in agents:
        raise HTTPException(status_code=404, detail="Агент не найден.")

    try:
        value = int(rel.get("value", 0))
    except (TypeError, ValueError):
        raise HTTPException(status_code=400, detail="Некорректное значение отношения.")

    value = max(-100, min(100, value))
    agents[src]["relations"][tgt] = value
    agents[tgt]["relations"][src] = value
    update_relationship(src, tgt, value)

    await broadcast_state()

    return {"status": "ok", "source": src, "target": tgt, "value": value}


# Создание или обновление агента (имя, личность, пол и т.д.); при создании автоматически добавляются рёбра в граф с остальными
@app.post("/agents")
async def upsert_agent(agent: Dict):
    global global_state
    agents = global_state["agents"]

    raw_id = str(agent.get("id") or agent.get("name") or "").strip()
    agent_id = re.sub(r"\D", "", raw_id)
    if not agent_id:
        numeric_ids = [int(k) for k in agents.keys() if k.isdigit()]
        next_id = (max(numeric_ids) + 1) if numeric_ids else 1
        agent_id = str(next_id)

    display_name = agent.get("name") or agent_id
    personality = agent.get("personality") or "Обычный человек"
    gender = agent.get("gender") or "человек"
    mood = agent.get("mood") or "neutral"
    plan = agent.get("plan") or agent.get("plans") or ""

    created = False

    if agent_id in agents:
        data = agents[agent_id]
        data["name"] = display_name
        data["personality"] = personality
        data["gender"] = gender
        data["mood"] = mood
        if plan:
            data["plans"] = plan
    else:
        agents[agent_id] = {
            "name": display_name,
            "personality": personality,
            "mood": mood,
            "memories": [],
            "plans": plan,
            "relations": {},
            "gender": gender,
        }
        for other_id, other in agents.items():
            if other_id == agent_id:
                continue
            other_rel = other.get("relations", {})
            other_rel.setdefault(agent_id, 0)
            other["relations"] = other_rel
            agents[agent_id]["relations"].setdefault(other_id, 0)
            update_relationship(agent_id, other_id, 0)
        created = True

    await broadcast_state()

    return {"status": "ok", "id": agent_id, "created": created}


@app.delete("/agents/{agent_id}")
async def delete_agent(agent_id: str):
    global global_state
    agents = global_state["agents"]
    if agent_id not in agents:
        raise HTTPException(status_code=404, detail="Агент не найден.")
    if agent_id in relations_graph:
        relations_graph.remove_node(agent_id)

    for other_id, other in agents.items():
        if other_id == agent_id:
            continue
        rels = other.get("relations", {})
        if agent_id in rels:
            rels.pop(agent_id, None)

    agents.pop(agent_id, None)

    await broadcast_state()

    return {"status": "ok", "deleted": agent_id}

@app.get("/")
def root():
    return {
        "message": "КИБЕР РЫВОК хакатон 2026 — сервер работает!",
        "docs": "Перейди сюда: /docs",
        "status": "online",
        "time": "симуляция агентов запущена"
    }


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)