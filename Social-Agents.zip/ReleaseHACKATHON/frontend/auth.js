// Базовый URL API: тот же хост, что и у страницы, порт 8000 (backend)
function apiBase() {
  return apiBase._cached;
}

(() => {
  const current = new URL(window.location.href);
  const host = current.hostname || "localhost";
  const protocol = current.protocol === "https:" ? "https:" : "http:";
  apiBase._cached = `${protocol}//${host}:8000`;
})();

function setHint(el, text, variant) {
  if (!el) return;
  el.textContent = text || "";
  if (variant) el.dataset.variant = variant;
}

function setFieldInvalid(inputEl, isInvalid) {
  if (!inputEl) return;
  if (isInvalid) inputEl.setAttribute("aria-invalid", "true");
  else inputEl.removeAttribute("aria-invalid");
}

// Токен сессии хранится в localStorage; при запросах передаётся в заголовке Authorization: Bearer <token>
function getToken() {
  return localStorage.getItem("authToken") || "";
}

function setToken(token) {
  if (token) localStorage.setItem("authToken", token);
}

function clearToken() {
  localStorage.removeItem("authToken");
}

// Проверка авторизации: GET /auth/me с Bearer-токеном; используется на index.html при загрузке
async function getMe() {
  const token = getToken();
  if (!token) return null;
  const res = await fetch(`${apiBase()}/auth/me`, {
    headers: { Authorization: "Bearer " + token },
  });
  if (!res.ok) return null;
  return await res.json().catch(() => null);
}

async function logout() {
  const token = getToken();
  if (token) {
    try {
      await fetch(`${apiBase()}/auth/logout`, {
        method: "POST",
        headers: { Authorization: "Bearer " + token },
      });
    } catch (_) {}
  }
  clearToken();
  window.location.href = "login.html";
}

// Общий метод для POST с JSON; ошибки приходят в data.detail (FastAPI)
async function postJson(path, body) {
  const res = await fetch(`${apiBase()}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body || {}),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data?.detail || `HTTP ${res.status}`);
  }
  return data;
}

async function register(username, password, displayName) {
  return await postJson("/auth/register", {
    username,
    password,
    display_name: displayName,
  });
}

async function login(username, password) {
  return await postJson("/auth/login", { username, password });
}

const loginForm = document.getElementById("loginForm");
if (loginForm) {
  const u = document.getElementById("loginUsername");
  const p = document.getElementById("loginPassword");
  const hint = document.getElementById("loginHint");

  u?.addEventListener("input", () => setFieldInvalid(u, false));
  p?.addEventListener("input", () => setFieldInvalid(p, false));

  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    setHint(hint, "", "info");
    const username = (u?.value || "").trim();
    const password = p?.value || "";
    if (!username || !password) {
      setFieldInvalid(u, !username);
      setFieldInvalid(p, !password);
      setHint(hint, "Заполни логин и пароль.", "error");
      return;
    }
    setHint(hint, "Входим…", "loading");
    try {
      const data = await login(username, password);
      setToken(data.token);
      setHint(hint, "Готово. Перенаправляю…", "success");
      window.location.href = "index.html";
    } catch (err) {
      setHint(hint, String(err.message || err), "error");
    }
  });
}

const registerForm = document.getElementById("registerForm");
if (registerForm) {
  const u = document.getElementById("regUsername");
  const n = document.getElementById("regDisplayName");
  const p1 = document.getElementById("regPassword");
  const p2 = document.getElementById("regPassword2");
  const hint = document.getElementById("registerHint");

  u?.addEventListener("input", () => setFieldInvalid(u, false));
  p1?.addEventListener("input", () => setFieldInvalid(p1, false));
  p2?.addEventListener("input", () => setFieldInvalid(p2, false));

  registerForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    setHint(hint, "", "info");
    const username = (u?.value || "").trim();
    const displayName = (n?.value || "").trim();
    const password = p1?.value || "";
    const password2 = p2?.value || "";

    if (!username || !password || !password2) {
      setFieldInvalid(u, !username);
      setFieldInvalid(p1, !password);
      setFieldInvalid(p2, !password2);
      setHint(hint, "Заполни логин и пароль.", "error");
      return;
    }
    if (password.length < 6) {
      setFieldInvalid(p1, true);
      setHint(hint, "Пароль должен быть минимум 6 символов.", "error");
      return;
    }
    if (password !== password2) {
      setFieldInvalid(p1, true);
      setFieldInvalid(p2, true);
      setHint(hint, "Пароли не совпадают.", "error");
      return;
    }

    setHint(hint, "Создаём аккаунт…", "loading");
    try {
      await register(username, password, displayName);
      setHint(hint, "Аккаунт создан. Теперь войди.", "success");
      window.location.href = "login.html";
    } catch (err) {
      setHint(hint, String(err.message || err), "error");
    }
  });
}

