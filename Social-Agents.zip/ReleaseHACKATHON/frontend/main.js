// main.js: главная страница симуляции. Проверка токена → редирект на login при отсутствии авторизации.
if (typeof getToken === "function" && !getToken()) {
  window.location.href = "login.html";
  throw new Error("redirect");
}

const API_PORT = 8000;

function getApiBase() {
  return getApiBase._cached;
}

// WebSocket /ws: получаем рассылку состояния (агенты, события, граф); отправка текста = новое событие от игрока
function buildWsUrl() {
  return buildWsUrl._cached;
}

(() => {
  const u = new URL(window.location.href);
  const host = u.hostname || "localhost";
  const isHttps = u.protocol === "https:";
  getApiBase._cached = `${isHttps ? "https:" : "http:"}//${host}:${API_PORT}`;
  buildWsUrl._cached = `${isHttps ? "wss:" : "ws:"}//${host}:${API_PORT}/ws`;
})();

let socket = null;
let lastState = null;
let renderedEvents = [];
let pendingEvents = [];
let eventsTimer = null;
const EVENT_INTERVAL_MS = 800;

const wsStatusEl = document.querySelector(".ws-status");
const wsTextEl = wsStatusEl?.querySelector(".ws-text");
const reconnectBtn = document.getElementById("reconnectBtn");
const controlToggleBtn = document.getElementById("controlToggleBtn");
const controlDrawer = document.getElementById("controlDrawer");
const navMainBtn = document.getElementById("navMain");
const navPairBtn = document.getElementById("navPair");
const mainLayout = document.getElementById("mainLayout");
const inputSection = document.getElementById("inputSection");
const pairSection = document.getElementById("pairSection");
const viewMain = document.getElementById("viewMain");
const viewPair = document.getElementById("viewPair");
const agentsListEl = document.getElementById("agentsList");
const agentsCountEl = document.getElementById("agentsCount");
const eventsListEl = document.getElementById("eventsList");
const userInputForm = document.getElementById("userInputForm");
const userInputEl = document.getElementById("userInput");
const graphCanvas = document.getElementById("graphCanvas");
const primaryButton = document.querySelector(".primary-button");
const historyBtn = document.getElementById("historyBtn");
const historyOverlay = document.getElementById("historyOverlay");
const historyCloseBtn = document.getElementById("historyCloseBtn");
const historyListEl = document.getElementById("historyList");
const relationForm = document.getElementById("relationForm");
const relationSourceSelect = document.getElementById("relationSource");
const relationTargetSelect = document.getElementById("relationTarget");
const relationValueInput = document.getElementById("relationValue");
const relationValueLabel = document.getElementById("relationValueLabel");
const relationHintEl = document.getElementById("relationHint");
const agentForm = document.getElementById("agentForm");
const agentSelect = document.getElementById("agentSelect");
const agentIdInput = document.getElementById("agentId");
const agentDisplayNameInput = document.getElementById("agentDisplayName");
const agentGenderSelect = document.getElementById("agentGender");
const agentMoodSelect = document.getElementById("agentMood");
const agentPersonalityInput = document.getElementById("agentPersonality");
const agentPlanInput = document.getElementById("agentPlan");
const agentDeleteBtn = document.getElementById("agentDeleteBtn");
const agentHintEl = document.getElementById("agentHint");
const pairSourceSelect = document.getElementById("pairSource");
const pairTargetSelect = document.getElementById("pairTarget");
const pairChatEl = document.getElementById("pairChat");
const agentsDataListEl = document.getElementById("agentsDataList");
const userLoginDisplay = document.getElementById("userLoginDisplay");
const logoutBtn = document.getElementById("logoutBtn");

let graphCtx = null;

if (typeof getMe === "function") {
  getMe().then(function (data) {
    if (userLoginDisplay && data && data.username) {
      userLoginDisplay.textContent = data.display_name || data.username;
    }
    if (data === null && typeof getToken === "function" && getToken()) {
      if (typeof clearToken === "function") clearToken();
      window.location.href = "login.html";
    }
  });
}
if (logoutBtn && typeof logout === "function") {
  logoutBtn.addEventListener("click", logout);
}

if (graphCanvas && graphCanvas.getContext) {
  graphCtx = graphCanvas.getContext("2d");
}

function setWsStatus(status) {
  if (!wsStatusEl || !wsTextEl) return;
  wsStatusEl.classList.remove("ws-status--connected", "ws-status--connecting", "ws-status--disconnected");
  if (status === "connected") {
    wsStatusEl.classList.add("ws-status--connected");
    wsTextEl.textContent = "Подключено к симуляции";
  } else if (status === "connecting") {
    wsStatusEl.classList.add("ws-status--connecting");
    wsTextEl.textContent = "Подключение…";
  } else {
    wsStatusEl.classList.add("ws-status--disconnected");
    wsTextEl.textContent = "Отключено";
  }
  if (primaryButton) {
    primaryButton.disabled = status !== "connected";
  }
}

function connectWs() {
  if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) {
    return;
  }

  setWsStatus("connecting");
  const url = buildWsUrl();

  try {
    socket = new WebSocket(url);
  } catch (e) {
    console.error("Не удалось создать WebSocket:", e);
    setWsStatus("disconnected");
    // Попробуем хотя бы один раз дернуть HTTP-стейт,
    // чтобы показать агентов без WebSocket.
    fetchInitialStateFallback();
    return;
  }

  socket.onopen = () => {
    setWsStatus("connected");
    fetchInitialStateFallback();
  };

  socket.onclose = () => {
    setWsStatus("disconnected");
  };

  socket.onerror = () => {
    setWsStatus("disconnected");
  };

  socket.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      lastState = data;
      updateRelationOptions(data.agents);
      renderAgents(data.agents);
      scheduleEventsUpdate(data.events);
      renderGraph(data.graph, data.agents);
    } catch (e) {
      console.error("Ошибка при обработке сообщения WebSocket:", e);
    }
  };
}

async function fetchInitialStateFallback() {
  try {
    const url = getApiBase() + "/state";
    const res = await fetch(url);
    if (!res.ok) return;
    const data = await res.json();
    if (!data) return;
    lastState = data;
    updateRelationOptions(data.agents);
    renderAgents(data.agents);
    scheduleEventsUpdate(data.events);
    renderGraph(data.graph, data.agents);
  } catch (e) {
    console.warn("Initial state fetch failed:", e);
  }
}

function renderAgents(agentsDict) {
  if (!agentsListEl) return;

  const agents = Object.values(agentsDict || {});
  if (!agents.length) {
    agentsListEl.innerHTML = '<p class="placeholder">Агенты пока не инициализированы…</p>';
    if (agentsCountEl) {
      agentsCountEl.textContent = "0 агентов";
    }
    return;
  }

  if (agentsCountEl) {
    agentsCountEl.textContent = `${agents.length} агент${agents.length === 1 ? "" : agents.length < 5 ? "а" : "ов"}`;
  }

  const html = [
    '<div class="agents-list">',
    ...Object.entries(agentsDict || {}).map(([agentId, agent]) => {
      const relations = agent.relations || {};
      const relNames = Object.keys(relations);
      const moodClass =
        agent.mood === "happy"
          ? "agent-mood agent-mood--happy"
          : agent.mood === "sad"
          ? "agent-mood agent-mood--sad"
          : agent.mood === "angry"
          ? "agent-mood agent-mood--angry"
          : "agent-mood";

      const memoriesPreview = (agent.memories || []).slice(-3).join(" · ");

      return `
        <article class="agent-card">
          <div class="agent-main">
            <div class="agent-name-row">
              <span class="agent-id">(id ${escapeHtml(agentId)})</span>
              <span class="agent-name">${escapeHtml(agent.name)}</span>
              <span class="${moodClass}">${escapeHtml(agent.mood || "neutral")}</span>
            </div>
            <div class="agent-tagline">
              <span class="agent-label">личность</span> — 
              <span class="agent-personality">${escapeHtml(agent.personality || "")}</span>
            </div>
            <div class="agent-plan">
              <div class="agent-label">план</div>
              <div class="agent-plan-text">${escapeHtml(agent.plans || "План ещё формируется…")}</div>
            </div>
          </div>
          <div>
            <div class="agent-label">память</div>
            <div class="agent-memories">
              ${memoriesPreview ? escapeHtml(memoriesPreview) : "Пока нет значимых воспоминаний."}
            </div>
            <div class="agent-label" style="margin-top:6px;">отношения</div>
            <div class="agent-relations">
              ${
                relNames.length
                  ? relNames
                      .map((otherId) => {
                        const val = relations[otherId];
                        const otherAgent = agentsDict[otherId];
                        const otherDisplay = (otherAgent && otherAgent.name) ? otherAgent.name : otherId;
                        let cl = "relation-chip";
                        if (val >= 70) cl += " relation-chip--love";
                        else if (val > 10) cl += " relation-chip--positive";
                        else if (val < -10) cl += " relation-chip--negative";
                        const label =
                          val >= 70 ? "❤ любовь" : val > 10 ? "дружба" : val < -10 ? "конфликт" : "нейтрально";
                        return `<span class="${cl}">${escapeHtml(otherDisplay)}: ${val} (${label})</span>`;
                      })
                      .join("")
                  : '<span class="relation-chip">Пока нет связей</span>'
              }
            </div>
          </div>
        </article>
      `;
    }),
    "</div>",
  ].join("");

  agentsListEl.innerHTML = html;
  renderPairChat();
}

function scheduleEventsUpdate(events) {
  if (!eventsListEl) return;

  if (!events || !events.length) {
    renderedEvents = [];
    pendingEvents = [];
    renderEventsInternal([]);
    return;
  }

  const known = new Set([...renderedEvents, ...pendingEvents]);
  const fresh = events.filter((e) => !known.has(e));

  if (!fresh.length) return;

  pendingEvents.push(...fresh);

  if (!eventsTimer) {
    eventsTimer = setInterval(() => {
      if (!pendingEvents.length) {
        clearInterval(eventsTimer);
        eventsTimer = null;
        return;
      }
      const next = pendingEvents.shift();
      renderedEvents.push(next);
      if (renderedEvents.length > 60) {
        renderedEvents = renderedEvents.slice(-60);
      }
      renderEventsInternal(renderedEvents);
    }, EVENT_INTERVAL_MS);
  }
}

function renderEventsInternal(events) {
  if (!eventsListEl) return;

  if (!events || !events.length) {
    eventsListEl.innerHTML = '<p class="placeholder">Здесь будут появляться события симуляции.</p>';
    return;
  }

  const isAtBottom =
    Math.abs(eventsListEl.scrollHeight - eventsListEl.scrollTop - eventsListEl.clientHeight) < 4;

  const html = events
    .map((raw, idx) => {
      const isPlayer = raw.startsWith("[Игрок]");
      const isLast = idx === events.length - 1;
      let cls = isPlayer ? "event-item event-item--player" : "event-item";
      if (isLast) cls += " event-item--new";

      const [prefix, ...rest] = raw.split(":");
      const text = rest.join(":").trim();

      return `
        <div class="${cls}">
          <span class="event-prefix">${escapeHtml(prefix || "")}:</span>
          <span class="event-text">${escapeHtml(text)}</span>
        </div>
      `;
    })
    .join("");

  eventsListEl.innerHTML = html;

  if (isAtBottom) {
    eventsListEl.scrollTop = eventsListEl.scrollHeight;
  }

  renderPairChat();
}

function renderGraph(edges, agentsDict) {
  if (!graphCtx || !graphCanvas) return;
  const w = graphCanvas.clientWidth || graphCanvas.width;
  const h = graphCanvas.clientHeight || graphCanvas.height;
  if (graphCanvas.width !== w) graphCanvas.width = w;
  if (graphCanvas.height !== h) graphCanvas.height = h;
  graphCtx.clearRect(0, 0, w, h);

  const agents = Object.keys(agentsDict || {});
  if (!agents.length) {
    graphCtx.fillStyle = "rgba(148,163,184,0.7)";
    graphCtx.font = "12px Kreadon, system-ui, sans-serif";
    graphCtx.fillText("Ожидаем агентов…", 16, 22);
    return;
  }

  const pad = 48;
  const innerW = Math.max(0, w - 2 * pad);
  const innerH = Math.max(0, h - 2 * pad);
  const centerX = pad + innerW / 2;
  const centerY = pad + innerH / 2;
  const radius = Math.min(innerW, innerH) / 2.6;

  const positions = {};
  agents.forEach((name, idx) => {
    const angle = (2 * Math.PI * idx) / agents.length - Math.PI / 2;
    positions[name] = {
      x: centerX + radius * Math.cos(angle),
      y: centerY + radius * Math.sin(angle),
    };
  });

  (edges || []).forEach((edge) => {
    const from = positions[edge.source];
    const to = positions[edge.target];
    if (!from || !to) return;

    const w = typeof edge.weight === "number" ? edge.weight : 0;
    let color = "#a855f7";
    if (w >= 70) color = "#fb7185";
    else if (w > 15) color = "#22c55e";
    else if (w < -15) color = "#ef4444";

    const thickness = 1 + Math.min(6, Math.abs(w) / 10);

    graphCtx.strokeStyle = color;
    graphCtx.lineWidth = thickness;
    graphCtx.globalAlpha = 0.9;

    graphCtx.beginPath();
    graphCtx.moveTo(from.x, from.y);
    graphCtx.lineTo(to.x, to.y);
    graphCtx.stroke();
  });

  agents.forEach((name) => {
    const pos = positions[name];
    const agent = agentsDict[name];
    const mood = agent?.mood;

    let fill = "#1d4ed8";
    if (mood === "happy") fill = "#22c55e";
    else if (mood === "sad") fill = "#3b82f6";
    else if (mood === "angry") fill = "#ef4444";

    const r = 16;
    const grad = graphCtx.createRadialGradient(pos.x - 3, pos.y - 3, r / 4, pos.x, pos.y, r);
    grad.addColorStop(0, "#f9fafb");
    grad.addColorStop(1, fill);

    graphCtx.beginPath();
    graphCtx.fillStyle = grad;
    graphCtx.strokeStyle = "rgba(15,23,42,0.95)";
    graphCtx.lineWidth = 2;
    graphCtx.arc(pos.x, pos.y, r, 0, Math.PI * 2);
    graphCtx.fill();
    graphCtx.stroke();

    graphCtx.font = "11px Kreadon, system-ui, sans-serif";
    graphCtx.textAlign = "center";
    graphCtx.textBaseline = "top";
    graphCtx.fillStyle = "rgba(226,232,240,0.95)";
    const label = agent && agent.name ? agent.name : name;
    graphCtx.fillText(label, pos.x, pos.y + r + 4);
  });
}

function escapeHtml(str) {
  if (str == null) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

if (userInputForm && userInputEl) {
  userInputForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const value = userInputEl.value.trim();
    if (!value || !socket || socket.readyState !== WebSocket.OPEN) return;
    socket.send(value);
    userInputEl.value = "";
  });

  userInputEl.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && e.ctrlKey) {
      e.preventDefault();
      userInputForm.dispatchEvent(new Event("submit", { cancelable: true }));
    }
  });
}

if (reconnectBtn) {
  reconnectBtn.addEventListener("click", () => {
    if (socket) {
      try {
        socket.close();
      } catch {}
    }
    connectWs();
  });
}

async function fetchHistory() {
  if (!historyListEl) return;
  historyListEl.innerHTML = '<p class="placeholder">Загрузка истории…</p>';
  try {
    const url = getApiBase() + "/history";
    const res = await fetch(url);
    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`);
    }
    const data = await res.json();
    const events = data.events || [];

    if (!events.length) {
      historyListEl.innerHTML = '<p class="history-empty">История пока пуста — симуляция ещё не начала общение.</p>';
      return;
    }

    const html = events
      .map((raw) => {
        const isPlayer = raw.startsWith("[Игрок]");
        const cls = isPlayer ? "history-item history-item--player" : "history-item";
        const [prefix, ...rest] = raw.split(":");
        const text = rest.join(":").trim();
        return `
          <div class="${cls}">
            <span class="history-item-prefix">${escapeHtml(prefix || "")}:</span>
            <span class="history-item-text">${escapeHtml(text)}</span>
          </div>
        `;
      })
      .join("");

    historyListEl.innerHTML = html;
  } catch (err) {
    console.error("Не удалось загрузить историю:", err);
    historyListEl.innerHTML = '<p class="history-empty">Не удалось загрузить историю. Проверьте, что сервер запущен.</p>';
  }
}

function openHistory() {
  if (!historyOverlay) return;
  historyOverlay.classList.add("is-open");
  fetchHistory();
}

function closeHistory() {
  if (!historyOverlay) return;
  historyOverlay.classList.remove("is-open");
}

if (historyBtn) {
  historyBtn.addEventListener("click", openHistory);
}

if (historyCloseBtn) {
  historyCloseBtn.addEventListener("click", closeHistory);
}

if (historyOverlay) {
  historyOverlay.addEventListener("click", (e) => {
    if (e.target === historyOverlay) {
      closeHistory();
    }
  });
}

// Первичное подключение
connectWs();

function updateRelationOptions(agentsDict) {
  if (!relationSourceSelect || !relationTargetSelect) return;
  const ids = Object.keys(agentsDict || {});
  if (!ids.length) return;

  const currentSrc = relationSourceSelect.value;
  const currentTgt = relationTargetSelect.value;

  const optionsHtml = ids
    .map((id) => {
      const a = agentsDict[id];
      const label = a && a.name ? `${a.name} (id: ${id})` : id;
      return `<option value="${escapeHtml(id)}">${escapeHtml(label)}</option>`;
    })
    .join("");

  relationSourceSelect.innerHTML = optionsHtml;
  relationTargetSelect.innerHTML = optionsHtml;
  if (ids.includes(currentSrc)) {
    relationSourceSelect.value = currentSrc;
  } else {
    relationSourceSelect.value = ids[0];
  }

  if (ids.includes(currentTgt) && currentTgt !== relationSourceSelect.value) {
    relationTargetSelect.value = currentTgt;
  } else {
    relationTargetSelect.value = ids[1] || ids[0];
  }
  if (agentSelect) {
    const currentAgent = agentSelect.value;
    const managerOptions =
      '<option value="">Новый агент…</option>' +
      ids
        .map((id) => {
          const a = agentsDict[id];
          const label = a && a.name ? `${a.name} (id: ${id})` : id;
          return `<option value="${escapeHtml(id)}">${escapeHtml(label)}</option>`;
        })
        .join("");
    agentSelect.innerHTML = managerOptions;
    if (currentAgent && ids.includes(currentAgent)) {
      agentSelect.value = currentAgent;
    }
  }
  renderAgentsData(agentsDict);
  if (pairSourceSelect && pairTargetSelect) {
    const currentPairSrc = pairSourceSelect.value;
    const currentPairTgt = pairTargetSelect.value;
    const displayNames = ids.map((id) => (agentsDict[id] && agentsDict[id].name) || id);
    const pairOptions = displayNames
      .map((nm) => `<option value="${escapeHtml(nm)}">${escapeHtml(nm)}</option>`)
      .join("");
    pairSourceSelect.innerHTML = pairOptions;
    pairTargetSelect.innerHTML = pairOptions;
    if (displayNames.includes(currentPairSrc)) {
      pairSourceSelect.value = currentPairSrc;
    } else {
      pairSourceSelect.value = displayNames[0];
    }
    if (displayNames.includes(currentPairTgt) && currentPairTgt !== pairSourceSelect.value) {
      pairTargetSelect.value = currentPairTgt;
    } else {
      pairTargetSelect.value = displayNames[1] || displayNames[0];
    }
  }

  syncRelationValueFromState();
}

function formatRelationLabel(value) {
  if (value >= 70) return "любовь";
  if (value >= 30) return "дружба";
  if (value > 5) return "симпатия";
  if (value <= -70) return "ненависть";
  if (value <= -30) return "вражда";
  if (value < -5) return "напряжение";
  return "нейтрально";
}

function syncRelationValueFromState() {
  if (!lastState || !relationSourceSelect || !relationTargetSelect || !relationValueInput || !relationValueLabel) return;
  const src = relationSourceSelect.value;
  const tgt = relationTargetSelect.value;
  const agents = lastState.agents || {};
  const srcAgent = agents[src];
  const val = srcAgent && srcAgent.relations ? srcAgent.relations[tgt] ?? 0 : 0;
  relationValueInput.value = String(val);
  const label = formatRelationLabel(val);
  relationValueLabel.textContent = `${val} · ${label}`;
}

if (relationSourceSelect && relationTargetSelect && relationValueInput && relationValueLabel) {
  relationSourceSelect.addEventListener("change", () => {
    if (relationSourceSelect.value === relationTargetSelect.value) {
      const options = Array.from(relationTargetSelect.options).map((o) => o.value);
      const other = options.find((n) => n !== relationSourceSelect.value);
      if (other) relationTargetSelect.value = other;
    }
    syncRelationValueFromState();
  });

  relationTargetSelect.addEventListener("change", () => {
    if (relationTargetSelect.value === relationSourceSelect.value) {
      const options = Array.from(relationSourceSelect.options).map((o) => o.value);
      const other = options.find((n) => n !== relationTargetSelect.value);
      if (other) relationSourceSelect.value = other;
    }
    syncRelationValueFromState();
  });

  relationValueInput.addEventListener("input", () => {
    const val = Number(relationValueInput.value);
    const label = formatRelationLabel(val);
    relationValueLabel.textContent = `${val} · ${label}`;
  });
}

if (relationForm) {
  relationForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!relationSourceSelect || !relationTargetSelect || !relationValueInput || !relationHintEl) return;
    const source = relationSourceSelect.value;
    const target = relationTargetSelect.value;
    if (!source || !target || source === target) {
      relationHintEl.textContent = "Выберите двух разных агентов.";
      return;
    }
    const value = Number(relationValueInput.value) || 0;

    relationHintEl.textContent = "Сохраняем...";
    try {
      const res = await fetch(getApiBase() + "/relations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ source, target, value }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const label = formatRelationLabel(value);
      relationHintEl.textContent = `Связь обновлена: ${value} · ${label}`;
      setTimeout(() => {
        if (relationHintEl.textContent.startsWith("Связь обновлена")) {
          relationHintEl.textContent = "";
        }
      }, 2500);
    } catch (err) {
      console.error("Не удалось обновить отношения:", err);
      relationHintEl.textContent = "Не удалось сохранить. Проверьте сервер.";
    }
  });
}

// Управление агентами

function fillAgentFormFromState(id) {
  if (!lastState || !agentIdInput || !agentDisplayNameInput || !agentGenderSelect || !agentMoodSelect || !agentPersonalityInput || !agentPlanInput) {
    return;
  }
  const agents = lastState.agents || {};
  const data = agents[id];
  if (!data) return;
  agentIdInput.value = id;
  agentDisplayNameInput.value = data.name || id;
  agentGenderSelect.value = data.gender || "человек";
  agentMoodSelect.value = data.mood || "neutral";
  agentPersonalityInput.value = data.personality || "";
  agentPlanInput.value = data.plans || "";
}

function clearAgentForm() {
  if (!agentIdInput || !agentDisplayNameInput || !agentGenderSelect || !agentMoodSelect || !agentPersonalityInput || !agentPlanInput) {
    return;
  }
  agentIdInput.value = "";
  agentDisplayNameInput.value = "";
  agentGenderSelect.value = "человек";
  agentMoodSelect.value = "neutral";
  agentPersonalityInput.value = "";
  agentPlanInput.value = "";
}

if (agentSelect) {
  agentSelect.addEventListener("change", () => {
    if (!agentSelect.value) {
      clearAgentForm();
    } else {
      fillAgentFormFromState(agentSelect.value);
    }
    if (agentHintEl) agentHintEl.textContent = "";
  });
}

if (agentForm) {
  agentForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (
      !agentIdInput ||
      !agentDisplayNameInput ||
      !agentGenderSelect ||
      !agentMoodSelect ||
      !agentPersonalityInput ||
      !agentPlanInput ||
      !agentHintEl
    ) {
      return;
    }

    const id = agentIdInput.value.trim() || agentDisplayNameInput.value.trim();
    if (!id) {
      agentHintEl.textContent = "Укажите хотя бы ID или имя агента.";
      return;
    }

    const payload = {
      id,
      name: agentDisplayNameInput.value.trim() || id,
      gender: agentGenderSelect.value || "человек",
      mood: agentMoodSelect.value || "neutral",
      personality: agentPersonalityInput.value.trim(),
      plan: agentPlanInput.value.trim(),
    };

    agentHintEl.textContent = "Сохраняем агента...";
    try {
      const res = await fetch(getApiBase() + "/agents", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      agentHintEl.textContent = data.created ? "Агент создан." : "Агент обновлён.";
      if (agentSelect) {
        agentSelect.value = id;
      }
      setTimeout(() => {
        if (agentHintEl.textContent.startsWith("Агент")) {
          agentHintEl.textContent = "";
        }
      }, 2500);
    } catch (err) {
      console.error("Не удалось сохранить агента:", err);
      agentHintEl.textContent = "Не удалось сохранить. Проверьте сервер.";
    }
  });
}

if (agentDeleteBtn) {
  agentDeleteBtn.addEventListener("click", async () => {
    if (!agentIdInput || !agentHintEl) return;
    const id = agentIdInput.value.trim();
    if (!id) {
      agentHintEl.textContent = "Сначала выберите или введите ID агента.";
      return;
    }

    agentHintEl.textContent = "Удаляем агента...";
    try {
      const res = await fetch(getApiBase() + "/agents/" + encodeURIComponent(id), { method: "DELETE" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      agentHintEl.textContent = "Агент удалён.";
      clearAgentForm();
      if (agentSelect) {
        agentSelect.value = "";
      }
      setTimeout(() => {
        if (agentHintEl.textContent.startsWith("Агент удалён")) {
          agentHintEl.textContent = "";
        }
      }, 2500);
    } catch (err) {
      console.error("Не удалось удалить агента:", err);
      agentHintEl.textContent = "Не удалось удалить. Проверьте сервер.";
    }
  });
}

if (agentIdInput) {
  agentIdInput.addEventListener("input", () => {
    agentIdInput.value = agentIdInput.value.replace(/\D/g, "");
  });
}

function renderAgentsData(agentsDict) {
  if (!agentsDataListEl) return;
  const entries = Object.entries(agentsDict || {});
  if (!entries.length) {
    agentsDataListEl.innerHTML = '<p class="placeholder">Нет данных об агентах.</p>';
    return;
  }

  entries.sort(([idA], [idB]) => {
    const a = parseInt(idA, 10);
    const b = parseInt(idB, 10);
    if (Number.isNaN(a) || Number.isNaN(b)) return idA.localeCompare(idB, "ru");
    return a - b;
  });

  const html = entries
    .map(([id, a]) => {
      const name = a.name || id;
      const gender = a.gender || "человек";
      const mood = a.mood || "neutral";
      const personality = a.personality || "";
      const relCount = a.relations ? Object.keys(a.relations).length : 0;
      return `
        <div class="agent-data-row">
          <div class="agent-data-id">ID: ${escapeHtml(id)} · Имя: ${escapeHtml(name)}</div>
          <div class="agent-data-main">
            Пол: ${escapeHtml(gender)} · Настроение: ${escapeHtml(mood)} · Связей: ${relCount}
          </div>
          <div class="agent-data-meta">
            Личность: ${escapeHtml(personality)}
          </div>
        </div>
      `;
    })
    .join("");

  agentsDataListEl.innerHTML = html;
}

if (controlToggleBtn && controlDrawer) {
  controlToggleBtn.addEventListener("click", () => {
    controlDrawer.classList.toggle("is-open");
  });

  const backdrop = controlDrawer.querySelector(".control-drawer-backdrop");
  if (backdrop) {
    backdrop.addEventListener("click", () => {
      controlDrawer.classList.remove("is-open");
    });
  }

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && controlDrawer.classList.contains("is-open")) {
      controlDrawer.classList.remove("is-open");
    }
  });
}

function setPageMode(mode) {
  if (!navMainBtn || !navPairBtn || !viewMain || !viewPair) return;
  setPageMode._token = (setPageMode._token || 0) + 1;
  const token = setPageMode._token;
  const SLIDE_PX = 30;

  const show = (el, displayValue, animate, slidePx) => {
    if (!el) return;
    el.classList.add("page-fade");
    el.style.setProperty("--page-slide", `${slidePx}px`);
    if (displayValue) el.style.display = displayValue;
    if (!animate) {
      el.classList.remove("page-fade--hidden");
      return;
    }
    el.classList.add("page-fade--hidden");
    // force reflow to ensure transition kicks in
    void el.offsetHeight;
    requestAnimationFrame(() => {
      if (setPageMode._token !== token) return;
      el.classList.remove("page-fade--hidden");
    });
  };

  const hide = (el, animate, slidePx) => {
    if (!el) return;
    el.classList.add("page-fade");
    el.style.setProperty("--page-slide", `${slidePx}px`);
    if (!animate) {
      el.classList.add("page-fade--hidden");
      return;
    }
    el.classList.add("page-fade--hidden");
  };

  const animate = setPageMode._didInit === true;

  if (mode === "pair") {
    viewPair.setAttribute("aria-hidden", "false");
    hide(viewMain, animate, -SLIDE_PX);
    show(viewPair, null, animate, SLIDE_PX);
    navMainBtn.classList.remove("nav-tab--active");
    navPairBtn.classList.add("nav-tab--active");
  } else {
    viewMain.setAttribute("aria-hidden", "false");
    hide(viewPair, animate, SLIDE_PX);
    show(viewMain, null, animate, -SLIDE_PX);
    viewPair.setAttribute("aria-hidden", "true");
    navPairBtn.classList.remove("nav-tab--active");
    navMainBtn.classList.add("nav-tab--active");
  }

  setPageMode._didInit = true;
}

if (navMainBtn && navPairBtn) {
  navMainBtn.addEventListener("click", () => setPageMode("main"));
  navPairBtn.addEventListener("click", () => setPageMode("pair"));
}
setPageMode("main");

function renderPairChat() {
  if (!pairChatEl || !pairSourceSelect || !pairTargetSelect || !lastState) return;
  const src = pairSourceSelect.value;
  const tgt = pairTargetSelect.value;
  if (!src || !tgt || src === tgt) {
    pairChatEl.innerHTML = '<p class="placeholder">Выберите двух разных агентов, и здесь появится их личный диалог.</p>';
    return;
  }

  const events = lastState.events || [];
  const cacheKey = `${src}|||${tgt}`;
  const lastEv = events.length ? String(events[events.length - 1]) : "";
  const cache = renderPairChat._cache;
  if (cache && cache.key === cacheKey && cache.len === events.length && cache.lastEv === lastEv) {
    pairChatEl.innerHTML = cache.html;
    pairChatEl.scrollTop = pairChatEl.scrollHeight;
    return;
  }
  if (!events.length) {
    const html = '<p class="placeholder">Пока нет совместных сообщений этих агентов.</p>';
    pairChatEl.innerHTML = html;
    renderPairChat._cache = { key: cacheKey, len: events.length, lastEv, html };
    return;
  }

  const pairMsgs = events.filter(
    (raw) => raw.startsWith(`${src} → ${tgt}:`) || raw.startsWith(`${tgt} → ${src}:`)
  );

  if (!pairMsgs.length) {
    const html = '<p class="placeholder">Пока нет совместных сообщений этих агентов.</p>';
    pairChatEl.innerHTML = html;
    renderPairChat._cache = { key: cacheKey, len: events.length, lastEv, html };
    return;
  }

  const html = pairMsgs
    .map((raw) => {
      const [prefix, ...rest] = raw.split(":");
      const text = rest.join(":").trim();
      const author = prefix.split("→")[0].trim();
      const isLeft = author === src;
      const cls = isLeft ? "pair-msg pair-msg--left" : "pair-msg pair-msg--right";
      return `
        <div class="${cls}">
          <div class="pair-msg-author">${author}</div>
          <div class="pair-msg-text">${escapeHtml(text)}</div>
        </div>
      `;
    })
    .join("");

  pairChatEl.innerHTML = html;
  pairChatEl.scrollTop = pairChatEl.scrollHeight;
  renderPairChat._cache = { key: cacheKey, len: events.length, lastEv, html };
}

if (pairSourceSelect && pairTargetSelect) {
  pairSourceSelect.addEventListener("change", renderPairChat);
  pairTargetSelect.addEventListener("change", renderPairChat);
}

